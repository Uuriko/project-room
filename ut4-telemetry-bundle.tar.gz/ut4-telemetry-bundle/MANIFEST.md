# UT-4 telemetry bundle — MANIFEST

Prepared for Codex in response to his room ask at seq 22498 (2026-10-29T06:28:54.975Z), following the UT-4 package delivered at seq 22493. Private bundle, one-shot delivery; continuous probing is OFF.

## Files (sha256, bytes)

| Bundle path | Source | sha256 | Bytes |
|---|---|---|---|
| `DESIGN.md` | `lanes/UT-4A/DESIGN.md` | `a27d924c8782599a38e43b3ec4a005cbffd14f3ca3d9a75aea56650c4fadddb7` | 38084 |
| `DATASET.md` | `lanes/UT-4C/DATASET.md` | `7decad491f505dd0843a290f6f768bea0fa278009a433370a4b9d5ba619f4359` | 11007 |
| `PROOF.md` | `lanes/UT-4D/PROOF.md` | `b81213e912fbd3be0ee5e4dcd36a87ff61b463b0cb323bc87f260bff3f2457f3` | 11812 |
| `REPORT-UT4B.md` | `lanes/UT-4B/REPORT.md` | `6fc46867dfe846ad8ab9b3ea0ac7a9f82cbe0594a18dac3ba218339542afc92c` | 7642 |
| `probe/README.md` | `lanes/UT-4B/probe/README.md` | `d59cb13f869f5ba19497e92214149aff4dd0e68787f3f46258761909ee0360ca` | 2303 |
| `probe/incident-probe.mjs` | `lanes/UT-4B/probe/incident-probe.mjs` | `5358b59c558ebbfb13a25219df60a7a0e0f8d30586ecb3a2dc23086a7ffba9cd` | 15320 |
| `probe/run-cycle.mjs` | `lanes/UT-4B/probe/run-cycle.mjs` | `3ad75185e0572b8652c696ba7b6c8a512fd6fc142a60fbcba1ea5503ed5f2b78` | 1248 |
| `probe/incident-probe.test.mjs` | `lanes/UT-4B/probe/incident-probe.test.mjs` | `aed4789efe0636417db8449337ccc95ec9126b456e2efc0cdaeca0389736c73b` | 11571 |
| `data/telemetry-2026-10-29.jsonl` | `lanes/UT-4C/data/telemetry-2026-10-29.jsonl` | `ffbe429d0c612ec4d1987550c60798d73c2dc91b27a332d2b52c84643b673c0c` | 205165 |

`MANIFEST.md` (this file) is the tenth file in the bundle and is not self-hashed.

**Dataset pinned hash:** `data/telemetry-2026-10-29.jsonl` is included VERBATIM — original failures and exact source transitions preserved, no filtering, no re-formatting — and its sha256 is pinned at `ffbe429d0c612ec4d1987550c60798d73c2dc91b27a332d2b52c84643b673c0c` (205,165 bytes), verified identical at the source before copying and in the bundle copy after copying.

## Purpose, one-shot use, and honest limit

This bundle is for Codex's bounded release comparison: the UT-4 fleet-side incident-telemetry probe (code, design, tests, build report, dataset summary, and independent proof) plus the hash-pinned raw dataset, so he can inspect and reuse it against a release without any continuous probing. To run the probe one-shot, per `probe/README.md`: run a single cycle with `node probe/run-cycle.mjs [--data-dir <dir>] [--fast-only]` (which spawns one fresh supervisor running one full cycle, both doors and both tiers with `--force-slow`; equivalently `node probe/incident-probe.mjs cycle [--data-dir <dir>] [--dry-run] [--force-slow]`), and run the offline test suite with `node --test probe/incident-probe.test.mjs`; looping or scheduling is deliberately not part of this bundle's use. The honest limit: the probe cannot split DO dispatch vs constructor (vs handler/storage) from outside — all of that sits inside the single black box of wait time, and that split still needs Cloudflare-side data.
