// incident-probe.mjs — fleet-side incident telemetry capture (UT-4B, trial instrument)
// Design: UT-4A DESIGN.md. One file, Node builtins only, no fleet-tools/ imports anywhere.
// Topology (F2 latch model): supervisor = writer-as-parent (spawns no git/python, does no
// network fetch, imports builtins only); worker = fetcher-as-child (spawns curl per leg,
// writes no file, emits records on stdout). Supervisor writes only after worker stdout EOF.
// Dataset writes: append + size/sha256 readback verify. Checkpoint: inlined atomic swap.
// Exit codes: 0 ok · 2 write-refused / tool error (payload on stdout) · 3 suspended.
import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { appendFileSync, closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync, readSync, renameSync, statSync, unlinkSync, writeSync } from 'node:fs';
import { hostname } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const UA = 'fleet-incident-telemetry/1 (UT-4)';
const DOORS = { app: 'https://room.trydemigod.com', entry: 'https://www.getdasha.com/room' };
const FAST_LEGS = [ ['version', '/api/version'], ['ready', '/api/ready'] ];
const SLOW_LEGS = [ ['receipts', '/api/public/receipts'], ['home', '/'], ['join', '/join'] ];
const W_TEMPLATE = '{"http_code":%{http_code},"time_namelookup":%{time_namelookup},"time_connect":%{time_connect},"time_appconnect":%{time_appconnect},"time_starttransfer":%{time_starttransfer},"time_total":%{time_total},"size_download":%{size_download},"remote_ip":"%{remote_ip}","http_version":"%{http_version}","redirect_url":"%{redirect_url}"}';
const sha256 = (s) => createHash('sha256').update(s).digest('hex');
const ms = (s) => Math.round(s * 1000);

// Phase derivation (DESIGN §2.2). Cumulative curl seconds -> separated phase ms.
// A stage whose cumulative value is 0 never completed: it and every later phase are
// null, never 0. For plain http (local stubs) TLS is not applicable: tls_ms=null,
// wait is measured from connect.
export function derivePhases(raw, isHttps) {
  const out = { dns_ms: null, tcp_ms: null, tls_ms: null, wait_ms: null, xfer_ms: null, total_ms: raw.time_total > 0 ? ms(raw.time_total) : null };
  if (!(raw.time_namelookup > 0)) return out;
  out.dns_ms = ms(raw.time_namelookup);
  if (!(raw.time_connect > 0)) return out;
  out.tcp_ms = ms(raw.time_connect - raw.time_namelookup);
  let base;
  if (isHttps) {
    if (!(raw.time_appconnect > 0)) return out;
    out.tls_ms = ms(raw.time_appconnect - raw.time_connect);
    base = raw.time_appconnect;
  } else { base = raw.time_connect; }
  if (!(raw.time_starttransfer > 0)) return out;
  out.wait_ms = ms(raw.time_starttransfer - base);
  if (!(raw.time_total > 0)) return out;
  out.xfer_ms = ms(raw.time_total - raw.time_starttransfer);
  return out;
}

export function buildLegRecord({ ts_ms, cycle_id, door, leg, tier, url, raw, curl_exit, error, body }) {
  const phases = derivePhases(raw, url.startsWith('https:'));
  const rec = {
    v: 1, type: 'leg', ts_ms, cycle_id, door, leg, tier, url,
    http_code: raw.http_code || 0,
    ...phases,
    cum_ms: {
      namelookup: raw.time_namelookup > 0 ? ms(raw.time_namelookup) : null,
      connect: raw.time_connect > 0 ? ms(raw.time_connect) : null,
      appconnect: raw.time_appconnect > 0 ? ms(raw.time_appconnect) : null,
      starttransfer: raw.time_starttransfer > 0 ? ms(raw.time_starttransfer) : null,
      total: raw.time_total > 0 ? ms(raw.time_total) : null,
    },
    body_bytes: raw.size_download || 0,
    remote_ip: raw.remote_ip || '', http_version: raw.http_version || '',
    redirect_url: raw.redirect_url || '', curl_exit, error: error || null,
  };
  if (body) {
    let parsed = null;
    try { parsed = JSON.parse(body.slice(0, 4096)); } catch { /* body kept as bytes only */ }
    if (parsed && leg === 'ready') {
      rec.ready_status = parsed.status ?? null;
      rec.do_status = parsed.do?.status ?? parsed.durableObject?.status ?? null;
      rec.do_timeout_ms = parsed.do?.timeoutMs ?? null;
      rec.do_ms = parsed.do?.ms ?? null;
    }
    if (parsed && leg === 'version') {
      rec.src_rev = typeof parsed.sourceRevision === 'string' ? parsed.sourceRevision.slice(0, 8) : null;
      rec.build_id = parsed.buildId ?? null;
    }
  } else {
    if (leg === 'ready') { rec.ready_status = null; rec.do_status = null; rec.do_timeout_ms = null; rec.do_ms = null; }
    if (leg === 'version') { rec.src_rev = null; rec.build_id = null; }
  }
  return rec;
}

// ---------------- worker (fetcher-as-child; writes no file, ever) ----------------
function runLeg(spec, legSpec) {
  return new Promise((resolve) => {
    const ts_ms = Date.now();
    const captureBody = legSpec.leg === 'version' || legSpec.leg === 'ready';
    const args = ['-sS', '--max-time', String(legSpec.tier === 'fast' ? 10 : 15), '-A', UA, '-w', W_TEMPLATE];
    if (!captureBody) args.push('-o', '/dev/null');
    args.push(legSpec.url);
    const child = spawn('curl', args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '', err = '';
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { err += d; });
    child.on('error', (e) => resolve({ rec: null, fatal: String(e) }));
    child.on('close', (code) => {
      const idx = out.lastIndexOf('{"http_code":');
      let raw = null, body = null;
      if (idx >= 0) {
        if (captureBody) body = out.slice(0, idx);
        try { raw = JSON.parse(out.slice(idx)); } catch { raw = null; }
      }
      if (!raw) {
        resolve({ rec: buildLegRecord({ ts_ms, cycle_id: spec.cycle_id, ...legSpec, raw: { http_code: 0, time_namelookup: 0, time_connect: 0, time_appconnect: 0, time_starttransfer: 0, time_total: 0, size_download: 0, remote_ip: '', http_version: '', redirect_url: '' }, curl_exit: code ?? -1, error: (err.split('\n')[0] || 'unparseable curl output').slice(0, 200), body: null }), fatal: null });
        return;
      }
      if (body !== null && body.length > 4096) body = body.slice(0, 4096);
      resolve({ rec: buildLegRecord({ ts_ms, cycle_id: spec.cycle_id, ...legSpec, raw, curl_exit: code ?? 0, error: code === 0 ? null : (err.split('\n')[0] || `curl exit ${code}`).slice(0, 200), body }), fatal: null });
    });
  });
}

async function workerMain(specJson) {
  const spec = JSON.parse(specJson);
  const lines = [];
  let cv = 'unknown';
  try { cv = spawnSync('curl', ['--version'], { encoding: 'utf8' }).stdout.split('\n')[0].trim() || 'unknown'; } catch { /* keep unknown */ }
  let aborted = null;
  const started = Date.now();
  for (const legSpec of spec.legs) {
    const { rec, fatal } = await runLeg(spec, legSpec);
    if (fatal || !rec) { process.stdout.write(JSON.stringify({ type: '_meta', curl_version: cv, fatal: fatal || 'no record', aborted: null, wall_ms: Date.now() - started }) + '\n'); return; }
    lines.push(JSON.stringify(rec));
    process.stdout.write(lines[lines.length - 1] + '\n');
    if (rec.http_code === 429 || rec.http_code === 403) {
      aborted = rec.http_code;
      const marker = { v: 1, type: rec.http_code === 429 ? 'ratelimit' : 'forbidden', ts_ms: Date.now(), cycle_id: spec.cycle_id, door: rec.door, leg: rec.leg, http_code: rec.http_code };
      process.stdout.write(JSON.stringify(marker) + '\n');
      break; // abort the cycle immediately (DESIGN §1 stop conditions)
    }
  }
  process.stdout.write(JSON.stringify({ type: '_meta', curl_version: cv, fatal: null, aborted, wall_ms: Date.now() - started }) + '\n');
}

// ---------------- supervisor (writer-as-parent) ----------------
function atomicSwap(target, content) { // inlined pattern, DESIGN §5.3 — never imported
  const tmp = `${target}.tmp-${process.pid}`;
  const fd = openSync(tmp, 'w');
  try { writeSync(fd, content); fsyncSync(fd); } finally { closeSync(fd); }
  const back = readFileSync(tmp, 'utf8');
  if (sha256(back) !== sha256(content)) { try { unlinkSync(tmp); } catch { /* ignore */ } const e = new Error('checkpoint verify mismatch'); e.code = 'EVERIFY'; throw e; }
  renameSync(tmp, target);
  try { const d = openSync(dirname(target), 'r'); fsyncSync(d); closeSync(d); } catch { /* best-effort */ }
}

function parseArgs(argv) {
  const a = { dataDir: join(dirname(fileURLToPath(import.meta.url)), 'data'), dryRun: false, forceSlow: false, bases: { ...DOORS } };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--data-dir') a.dataDir = argv[++i];
    else if (argv[i] === '--dry-run') a.dryRun = true;
    else if (argv[i] === '--force-slow') a.forceSlow = true;
    else if (argv[i] === '--base-app') a.bases.app = argv[++i];
    else if (argv[i] === '--base-entry') a.bases.entry = argv[++i];
    else throw new Error(`unknown arg ${argv[i]}`);
  }
  return a;
}

function readCheckpoint(dataDir) {
  try { return JSON.parse(readFileSync(join(dataDir, 'checkpoint.json'), 'utf8')); } catch { return {}; }
}

function lastTrailerTs(dataDir, now) {
  for (const offset of [0, 1]) {
    try {
      const d = new Date(now - offset * 86400000);
      const p = join(dataDir, `telemetry-${d.toISOString().slice(0, 10)}.jsonl`);
      if (!existsSync(p)) continue;
      const text = readFileSync(p, 'utf8');
    const idx = text.lastIndexOf('"type":"cycle"');
    if (idx < 0) continue;
    const line = text.slice(text.lastIndexOf('\n', idx) + 1, text.indexOf('\n', idx) < 0 ? undefined : text.indexOf('\n', idx));
    try { const rec = JSON.parse(line); if (rec.ts_ms) return rec.ts_ms; } catch { /* keep looking */ }
    } catch { continue; } // unreadable dataset tail = no trailer; the append path decides refusal
  }
  return null;
}

function runWorker(spec) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [fileURLToPath(import.meta.url), '--worker', JSON.stringify(spec)], { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '', err = '';
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { err += d; });
    child.on('error', reject);
    child.on('close', (code) => resolve({ out, err, code }));
  });
}

async function cycleMain(argv) {
  const opts = parseArgs(argv);
  const now = Date.now();
  const cp = opts.dryRun ? {} : readCheckpoint(opts.dataDir);
  if (cp.suspended_until_ts_ms && cp.suspended_until_ts_ms > now) {
    process.stderr.write(`SUSPENDED incident-probe until=${new Date(cp.suspended_until_ts_ms).toISOString()} (rate-limit suspension honoured)\n`);
    process.exitCode = 3; return;
  }
  const seq = (cp.cycle_seq || 0) + 1;
  const cycle_id = `${new Date(now).toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '')}-${String(seq).padStart(4, '0')}`;
  const slowDue = opts.forceSlow || !cp.last_slow_ts_ms || (now - cp.last_slow_ts_ms >= 5 * 60 * 1000);
  const legs = [];
  for (const door of ['app', 'entry']) for (const [leg, path] of FAST_LEGS) legs.push({ door, leg, tier: 'fast', url: opts.bases[door] + path });
  if (slowDue) for (const door of ['app', 'entry']) for (const [leg, path] of SLOW_LEGS) legs.push({ door, leg, tier: 'slow', url: opts.bases[door] + path });

  const { out, code: workerCode } = await runWorker({ cycle_id, legs });
  const rawLines = out.split('\n').filter((l) => l.trim().length > 0);
  let meta = null; const legLines = [];
  for (const l of rawLines) { try { const o = JSON.parse(l); if (o.type === '_meta') meta = o; else legLines.push(l); } catch { /* drop non-JSON */ } }

  const records = [];
  const dayFile = join(opts.dataDir, `telemetry-${new Date(now).toISOString().slice(0, 10)}.jsonl`);
  let fileExists = false;
  try { const st = statSync(dayFile); fileExists = st.isFile() && st.size > 0; } catch { fileExists = false; }
  if (!fileExists) records.push(JSON.stringify({ v: 1, type: 'header', tool: 'incident-probe', tool_version: '1.0', curl_version: meta?.curl_version || 'unknown', host: hostname(), started_ts_ms: now }));

  if (!opts.dryRun) {
    const prev = lastTrailerTs(opts.dataDir, now);
    if (prev && now - prev > 60000) records.push(JSON.stringify({ v: 1, type: 'gap', from_ts_ms: prev, to_ts_ms: now, missed_cycles_est: Math.max(1, Math.round((now - prev) / 30000) - 1) }));
  }
  records.push(...legLines);
  if (!meta || meta.fatal || workerCode !== 0 && !meta) {
    records.push(JSON.stringify({ v: 1, type: 'tool_error', ts_ms: Date.now(), cycle_id, error: String(meta?.fatal || `worker exit ${workerCode}`).slice(0, 200) }));
  }
  const trailer = { v: 1, type: 'cycle', cycle_id, ts_ms: now, written_ts_ms: Date.now(), legs: legLines.filter((l) => l.includes('"type":"leg"')).length, wall_ms: meta?.wall_ms ?? null, slow_ran: slowDue };
  records.push(JSON.stringify(trailer));
  const payload = records.join('\n') + '\n';

  if (opts.dryRun) { process.stdout.write(payload); return; }

  // Dataset append, exactly DESIGN §5.2: append, then size + sha256 readback of the appended range.
  mkdirSync(opts.dataDir, { recursive: true });
  const sizeBefore = existsSync(dayFile) ? statSync(dayFile).size : 0;
  try {
    appendFileSync(dayFile, payload);
    const sizeAfter = statSync(dayFile).size;
    if (sizeAfter !== sizeBefore + Buffer.byteLength(payload)) { const e = new Error(`size mismatch ${sizeBefore} -> ${sizeAfter}`); e.code = 'EVERIFY'; throw e; }
    const fd = openSync(dayFile, 'r');
    const buf = Buffer.alloc(Buffer.byteLength(payload));
    readSync(fd, buf, 0, buf.length, sizeBefore); closeSync(fd);
    if (sha256(buf.toString('utf8')) !== sha256(payload)) { const e = new Error('sha256 readback mismatch'); e.code = 'EVERIFY'; throw e; }
  } catch (e) {
    // WRITE-REFUSED fallback (DESIGN §5.4): payload verbatim on stdout, one stderr line, exit 2. No retry in this subtree.
    process.stdout.write(payload);
    process.stderr.write(`WRITE-REFUSED incident-probe cycle=${cycle_id} code=${e.code || 'EIO'} lines=${records.length} bytes=${Buffer.byteLength(payload)}\n`);
    process.exitCode = 2; return;
  }

  // Checkpoint after data (record-before-state). Refusal is non-fatal but logged.
  const suspended = meta?.aborted ? now + 15 * 60 * 1000 : (cp.suspended_until_ts_ms && cp.suspended_until_ts_ms > now ? cp.suspended_until_ts_ms : 0);
  const newCp = { last_cycle_ts_ms: now, last_slow_ts_ms: slowDue ? now : (cp.last_slow_ts_ms || 0), last_cycle_id: cycle_id, cycle_seq: seq, suspended_until_ts_ms: suspended, last_write_status: 'ok' };
  try { atomicSwap(join(opts.dataDir, 'checkpoint.json'), JSON.stringify(newCp) + '\n'); }
  catch (e) { process.stderr.write(`CHECKPOINT-REFUSED incident-probe cycle=${cycle_id} code=${e.code || 'EIO'}\n`); }
  if (meta?.aborted) process.stderr.write(`CYCLE-ABORTED incident-probe cycle=${cycle_id} http_code=${meta.aborted} suspended_until=${new Date(suspended).toISOString()}\n`);
  if (!meta || meta.fatal) process.exitCode = 2;
}

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMain) {
  if (process.argv[2] === '--worker') { await workerMain(process.argv[3]); }
  else if (process.argv[2] === 'cycle') { await cycleMain(process.argv.slice(3)); }
  else { process.stderr.write('usage: node incident-probe.mjs cycle [--data-dir <dir>] [--dry-run] [--force-slow] [--base-app <url>] [--base-entry <url>]\n'); process.exitCode = 64; }
}
