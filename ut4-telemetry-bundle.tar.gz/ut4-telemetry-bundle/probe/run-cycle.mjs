// run-cycle.mjs — UT-4C cycle runner: executes ONE full cycle on demand (both doors,
// both tiers) by spawning incident-probe.mjs as a fresh top-level supervisor process.
// Builtins only; this runner does no fetching and no dataset writing itself — the
// supervisor it spawns owns the write path. Loops are the caller's job: invoke this
// once per cycle (e.g. every 30 s from cron/systemd); --force-slow is always passed
// here so a runner cycle is a full 10-leg cycle. Pass --fast-only to skip that.
// Exit code is the supervisor's exit code (0 ok · 2 write-refused · 3 suspended).
import { spawn } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const fastOnly = args.includes('--fast-only');
const probeArgs = ['cycle', ...(fastOnly ? [] : ['--force-slow']), ...args.filter((a) => a !== '--fast-only')];
const child = spawn(process.execPath, [join(here, 'incident-probe.mjs'), ...probeArgs], { stdio: 'inherit' });
child.on('error', (e) => { process.stderr.write(`RUNNER-ERROR ${e}\n`); process.exitCode = 2; });
child.on('close', (code) => { process.exitCode = code ?? 2; });
