// incident-probe.test.mjs — offline tests (DESIGN §8.3 a-e + T1-analogue latch test).
// Run: TMPDIR=<scratch> node --test incident-probe.test.mjs   (live smoke is separate)
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { buildLegRecord, derivePhases } from './incident-probe.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const PROBE = join(HERE, 'incident-probe.mjs');
const dayName = () => `telemetry-${new Date().toISOString().slice(0, 10)}.jsonl`;
const mkData = () => mkdtempSync(join(tmpdir(), 'ut4b-test-'));
const sha = (s) => createHash('sha256').update(s).digest('hex');

function runProbe(args) {
  return new Promise((resolve) => {
    const c = spawn(process.execPath, [PROBE, ...args], { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '', err = '';
    c.stdout.on('data', (d) => { out += d; });
    c.stderr.on('data', (d) => { err += d; });
    c.on('close', (code) => resolve({ code, out, err }));
  });
}

function stub(mode) {
  const server = createServer((req, res) => {
    const url = req.url;
    if (url.includes('/api/ready') && mode === 'ratelimit') { res.writeHead(429); res.end('slow down'); return; }
    if (url.includes('/api/ready') && mode === 'forbidden') { res.writeHead(403); res.end('blocked'); return; }
    if (url.includes('/api/version')) { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ sourceRevision: 'abcdef1234567890', buildId: 'test-build' })); return; }
    if (url.includes('/api/ready')) { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ status: 'degraded', do: { status: 'timeout', timeoutMs: 1000, ms: 1000 } })); return; }
    res.writeHead(200); res.end('hello-body');
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve({ server, base: `http://127.0.0.1:${server.address().port}` })));
}
const seedCp = (dir, extra = {}) => writeFileSync(join(dir, 'checkpoint.json'), JSON.stringify({ last_slow_ts_ms: Date.now(), cycle_seq: 0, ...extra }));
const readDataset = (dir) => readFileSync(join(dir, dayName()), 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));

// (a) derivation unit tests — recorded-shape curl outputs
test('derive: healthy https phases separate', () => {
  const p = derivePhases({ time_namelookup: 0.0107, time_connect: 0.0134, time_appconnect: 0.505, time_starttransfer: 0.8767, time_total: 0.8768 }, true);
  assert.deepEqual(p, { dns_ms: 11, tcp_ms: 3, tls_ms: 492, wait_ms: 372, xfer_ms: 0, total_ms: 877 });
});
test('derive: TLS failure => tls/wait/xfer null, never 0', () => {
  const p = derivePhases({ time_namelookup: 0.003, time_connect: 0.005, time_appconnect: 0, time_starttransfer: 0, time_total: 0.2 }, true);
  assert.equal(p.dns_ms, 3); assert.equal(p.tcp_ms, 2);
  assert.equal(p.tls_ms, null); assert.equal(p.wait_ms, null); assert.equal(p.xfer_ms, null);
});
test('derive: timeout before first byte => wait/xfer null', () => {
  const p = derivePhases({ time_namelookup: 0.003, time_connect: 0.005, time_appconnect: 0.3, time_starttransfer: 0, time_total: 10 }, true);
  assert.equal(p.tls_ms, 295); assert.equal(p.wait_ms, null); assert.equal(p.xfer_ms, null); assert.equal(p.total_ms, 10000);
});
test('record: 503 ready body fields parsed; incomplete phases null in record', () => {
  const rec = buildLegRecord({ ts_ms: 1, cycle_id: 'c', door: 'app', leg: 'ready', tier: 'fast', url: 'https://x/api/ready', raw: { http_code: 503, time_namelookup: 0.002, time_connect: 0.003, time_appconnect: 0.3, time_starttransfer: 1.8, time_total: 1.83, size_download: 182, remote_ip: '1.2.3.4', http_version: '2', redirect_url: '' }, curl_exit: 0, error: null, body: '{"status":"degraded","do":{"status":"timeout","timeoutMs":1000,"ms":1000}}' });
  assert.equal(rec.http_code, 503); assert.equal(rec.ready_status, 'degraded'); assert.equal(rec.do_status, 'timeout'); assert.equal(rec.do_ms, 1000); assert.equal(rec.wait_ms, 1500);
});

// (b) schema on a fixture cycle against a local stub (both doors, both tiers)
test('stub full cycle: schema-valid records for all 10 legs', async () => {
  const { server, base } = await stub('normal');
  const dir = mkData();
  try {
    const r = await runProbe(['cycle', '--data-dir', dir, '--force-slow', '--base-app', base, '--base-entry', base + '/room']);
    assert.equal(r.code, 0, r.err);
    const recs = readDataset(dir);
    assert.equal(recs[0].type, 'header'); assert.match(recs[0].curl_version, /^curl /);
    const legs = recs.filter((x) => x.type === 'leg');
    assert.equal(legs.length, 10);
    for (const l of legs) {
      assert.equal(typeof l.ts_ms, 'number'); assert.ok(l.ts_ms > 1e12);
      for (const k of ['dns_ms', 'tcp_ms', 'tls_ms', 'wait_ms', 'xfer_ms', 'total_ms']) assert.ok(l[k] === null || typeof l[k] === 'number', `${k} on ${l.door}/${l.leg}`);
      assert.equal(l.http_code, 200); assert.equal(typeof l.body_bytes, 'number');
    }
    const v = legs.find((l) => l.leg === 'version'); assert.equal(v.src_rev, 'abcdef12'); assert.equal(v.build_id, 'test-build');
    const rd = legs.find((l) => l.leg === 'ready'); assert.equal(rd.do_status, 'timeout'); assert.equal(rd.do_timeout_ms, 1000);
    const trailer = recs.at(-1); assert.equal(trailer.type, 'cycle'); assert.equal(trailer.legs, 10); assert.equal(trailer.slow_ran, true);
  } finally { server.close(); }
});

// (d) gap marker: backdated trailer => in-band gap record naming bounds
test('gap marker on stale trailer', async () => {
  const { server, base } = await stub('normal');
  const dir = mkData();
  const old = Date.now() - 10 * 60 * 1000;
  writeFileSync(join(dir, dayName()), JSON.stringify({ v: 1, type: 'header', tool: 'incident-probe' }) + '\n' + JSON.stringify({ v: 1, type: 'cycle', cycle_id: 'old', ts_ms: old, written_ts_ms: old, legs: 4, wall_ms: 1, slow_ran: false }) + '\n');
  seedCp(dir);
  try {
    const r = await runProbe(['cycle', '--data-dir', dir, '--base-app', base, '--base-entry', base]);
    assert.equal(r.code, 0, r.err);
    const gap = readDataset(dir).find((x) => x.type === 'gap');
    assert.ok(gap, 'gap record present'); assert.equal(gap.from_ts_ms, old); assert.ok(gap.to_ts_ms > old); assert.ok(gap.missed_cycles_est >= 10);
  } finally { server.close(); }
});

// (e) ratelimit: 429 aborts cycle, marker lands, suspension honoured; 403 same path
for (const [mode, code] of [['ratelimit', 429], ['forbidden', 403]]) {
  test(`${mode}: ${code} aborts cycle + suspends`, async () => {
    const { server, base } = await stub(mode);
    const dir = mkData(); seedCp(dir);
    try {
      const r = await runProbe(['cycle', '--data-dir', dir, '--base-app', base, '--base-entry', base]);
      assert.equal(r.code, 0, r.err); // cycle itself lands; abort is in-band
      const recs = readDataset(dir);
      const legs = recs.filter((x) => x.type === 'leg');
      assert.equal(legs.length, 2, 'app version + app ready only — cycle aborted');
      const marker = recs.find((x) => x.type === mode);
      assert.ok(marker, `${mode} marker present`); assert.equal(marker.http_code, code);
      const sizeAfterAbort = statSync(join(dir, dayName())).size;
      const r2 = await runProbe(['cycle', '--data-dir', dir, '--base-app', base, '--base-entry', base]);
      assert.equal(r2.code, 3, 'suspended run exits 3'); assert.match(r2.err, /SUSPENDED/);
      assert.equal(statSync(join(dir, dayName())).size, sizeAfterAbort, 'no writes while suspended');
      const cp = JSON.parse(readFileSync(join(dir, 'checkpoint.json'), 'utf8'));
      assert.ok(cp.suspended_until_ts_ms > Date.now() + 10 * 60 * 1000, 'suspension ~15 min');
    } finally { server.close(); }
  });
}

// (c) latched-subtree (T1 analogue): git executed in the spawning parent first.
// Pass = writer lands exactly once via its fresh subtree, OR refuses loudly:
// exit 2 + WRITE-REFUSED stderr + full payload on stdout + dataset byte-identical.
test('latched parent: lands via fresh subtree OR refuses loudly, never silent', async () => {
  const { server, base } = await stub('normal');
  const dir = mkData(); seedCp(dir);
  const sentinel = JSON.stringify({ v: 1, type: 'header', tool: 'sentinel' }) + '\n';
  writeFileSync(join(dir, dayName()), sentinel);
  const wrapper = join(dir, 'wrapper.mjs');
  writeFileSync(wrapper, `
import { spawn, spawnSync } from 'node:child_process';
spawnSync('git', ['--version'], { encoding: 'utf8' }); // arm the latch in this parent
const c = spawn(process.execPath, [${JSON.stringify(PROBE)}, 'cycle', '--data-dir', ${JSON.stringify(dir)}, '--base-app', ${JSON.stringify(base)}, '--base-entry', ${JSON.stringify(base)}], { stdio: ['ignore', 'pipe', 'pipe'] });
let out = '', err = '';
c.stdout.on('data', (d) => { out += d; }); c.stderr.on('data', (d) => { err += d; });
c.on('close', (code) => { process.stdout.write(JSON.stringify({ code, out, err })); });
`);
  try {
    const res = await new Promise((resolve) => {
      const c = spawn(process.execPath, [wrapper], { stdio: ['ignore', 'pipe', 'pipe'] });
      let out = ''; c.stdout.on('data', (d) => { out += d; });
      c.on('close', () => resolve(JSON.parse(out)));
    });
    const after = readFileSync(join(dir, dayName()), 'utf8');
    assert.ok(!existsSync(join(dir, 'checkpoint.json.tmp-' + process.pid)));
    if (res.code === 0) {
      assert.ok(after.length > sentinel.length, 'landed');
      assert.equal(after.split('"type":"cycle"').length - 1, 1, 'exactly one trailer appended');
      assert.ok(after.startsWith(sentinel), 'prior bytes untouched');
    } else {
      assert.equal(res.code, 2); assert.match(res.err, /WRITE-REFUSED/);
      assert.equal(sha(after), sha(sentinel), 'dataset byte-identical on refusal');
      assert.ok(res.out.includes('"type":"leg"'), 'payload carried on stdout');
    }
  } finally { server.close(); }
});

// Forced refusal (deterministic): dataset path is a directory => EISDIR down the same
// §5.4 fallback: exit 2, WRITE-REFUSED, payload on stdout, target untouched.
test('write-refused fallback: payload on stdout, nothing truncated', async () => {
  const { server, base } = await stub('normal');
  const dir = mkData(); seedCp(dir);
  mkdirSync(join(dir, dayName()));
  try {
    const r = await runProbe(['cycle', '--data-dir', dir, '--base-app', base, '--base-entry', base]);
    assert.equal(r.code, 2); assert.match(r.err, /WRITE-REFUSED incident-probe cycle=/);
    const lines = r.out.split('\n').filter(Boolean).map((l) => JSON.parse(l));
    assert.ok(lines.some((x) => x.type === 'leg')); assert.ok(lines.some((x) => x.type === 'cycle'));
    assert.ok(statSync(join(dir, dayName())).isDirectory(), 'target untouched');
  } finally { server.close(); }
});

// T5 grep: no fleet-tools/ import in the write path
test('T5: no fleet-tools import, builtins only', () => {
  const src = readFileSync(PROBE, 'utf8');
  assert.ok(!/from\s+['"][^'"]*fleet-tools/.test(src), 'no fleet-tools import');
  for (const m of src.matchAll(/from\s+['"]([^'"]+)['"]/g)) assert.ok(m[1].startsWith('node:'), `builtin only: ${m[1]}`);
  assert.ok(!src.includes("spawn('git'") && !src.includes('spawn("git"'), 'supervisor/worker never spawn git');
});
