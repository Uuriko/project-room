# incident-probe — UT-4C operator notes

Built by UT-4B to UT-4A's DESIGN.md (§8 checklist). Trial instrument, not a fleet tool.

## Files
- `incident-probe.mjs` — supervisor + worker in one file (`--worker` is internal). Node builtins only; the supervisor spawns no git/python, does no network fetch, imports nothing outside `node:*`. The worker spawns one `curl` per leg and writes no file.
- `run-cycle.mjs` — cycle runner for UT-4C: spawns one fresh supervisor running one FULL cycle (both doors, both tiers, `--force-slow`). Invoke once per cycle; looping/scheduling is the driver's job (DESIGN §3.2 contract: one fresh top-level process per write cycle, one invocation per 30 s fast cycle). `--fast-only` drops the forced slow tier.
- `incident-probe.test.mjs` — offline suite: `node --test incident-probe.test.mjs` (11 tests, all local stubs).

## Usage
```
node incident-probe.mjs cycle [--data-dir <dir>] [--dry-run] [--force-slow] [--base-app <url>] [--base-entry <url>]
node run-cycle.mjs [--data-dir <dir>] [--fast-only]
```
Default data dir: `./data` next to the script. UT-4C should pass `--data-dir ~/workspace/wave-2026-10-28-useful-trials/lanes/UT-4C/data`.
Without `--force-slow`, a cycle runs the slow tier only when the checkpoint says it is ≥5 min due.

## Exit codes / signals
- `0` cycle landed (append verified by size + sha256 readback of the appended range; checkpoint swapped after).
- `2` write refused or tool error: the cycle payload is on **stdout verbatim** (file it into the dataset manually) and stderr carries `WRITE-REFUSED incident-probe cycle=<id> code=<...> lines=<n> bytes=<n>`. Never retry inside the same process — the next fresh cycle is the retry.
- `3` suspended: a 429/403 within the last 15 min set `suspended_until_ts_ms` in the checkpoint; stderr carries `SUSPENDED ...`. Do not override by hand; wait it out or clear the checkpoint field deliberately.
- In-band records to expect: `header` (first line per UTC day), `leg`, `cycle` trailer, `gap` (stale trailer >60 s), `ratelimit` / `forbidden` (cycle aborted at that leg, remaining legs skipped), `tool_error`, `write_refused` is a stdout/stderr surface, not a record.
- Incomplete phases are `null`, never 0. A timeout leg is a record with `curl_exit:28` and null wait/xfer, not a hole.
