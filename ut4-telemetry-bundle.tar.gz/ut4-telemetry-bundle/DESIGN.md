# UT-4A — DESIGN: fleet-side incident telemetry capture

**Lane:** UT-4A (design only). **Builds on this:** UT-4B (build), UT-4C (run + dataset).
**Close state of this design:** FILED at `~/workspace/wave-2026-10-28-useful-trials/lanes/UT-4A/DESIGN.md`.
**Posture:** read-only against production — GET probes only, no auth, no POSTs, no headers beyond curl defaults. No room posts from the capture itself.

## 0. Problem, in one paragraph

Codex's rank-1 ask (incident 5177, window 02:39–02:51Z, 12 minutes) could not be answered: decomposing Durable Object dispatch / constructor / handler time needs Cloudflare stored telemetry behind John's authorization, which the fleet does not have. This design is the substitute the fleet *can* own: continuous external HTTPS probes of both production doors whose per-phase timing is measured by our own process, stored in our own append-only dataset, so the **next** incident window is decomposable from fleet custody with zero new authorization. §6 states exactly which decomposition claims this supports and which it honestly cannot — the DO-internal split (dispatch vs constructor vs handler) remains behind John's authorization, and this design does not pretend otherwise.

Sources this design is built from (all read at source by this lane):
- Wave STATE.md (trial UT-4 charter, kill criterion: "the probe cannot separate phases … or its own write path cannot survive the EPERM episode").
- `~/workspace/fleet-tools/README-door-monitor.md` (v1.1) — probe set, doors, alert precedent, 429 discipline.
- `~/workspace/wave-2026-10-28-figure-out/SYNTHESIS.md` §F2 and lanes F2-06 (winning latch model, fleet standard §5) and F2-07 (consumer topology §1.1, acceptance tests §6) — the write-path rules in §5 below.
- Live spot-check executed by this lane 2026-10-28 ~22:50–23:05 PT (numbers in §7).

---

## 1. Legs

URL construction is **base + leg, verbatim, no normalisation** — identical to door-monitor v1.1, so the two datasets stay comparable.

| Door id | Base |
|---|---|
| `app` | `https://room.trydemigod.com` |
| `entry` | `https://www.getdasha.com/room` |

| Leg id | Path appended | Tier | What it is for |
|---|---|---|---|
| `version` | `/api/version` | fast | Control leg. Tiny JSON (207 B spot-checked) carrying `sourceRevision` + `buildId`. Treated as the non-DO baseline: if `version` wait-time is flat while `ready` wait-time inflates, the inflation is DO-path-specific (§6). Caveat recorded: version's handler internals are not visible from outside; it is a *working* control, and §6 names the co-movement check that would invalidate it. |
| `ready` | `/api/ready` | fast | The DO-touching leg. Its body embeds a DO probe: spot-checked live body was `{"status":"degraded",…,"durableObject":{"ready":false,"status":"timeout"},"do":{"status":"timeout","timeoutMs":1000,"ms":1000}}`. This is the closest external observable to DO health that exists without authorization. |
| `receipts` | `/api/public/receipts` | slow | Public read surface (15,436 B spot-checked, identical bytes on both doors). The canonical path — **not** `/api/receipts`, which never existed (door-monitor v1.0 false-positive lesson, README v1.1 note). |
| `home` | `/` | slow | Door home. On `entry` this is `https://www.getdasha.com/room/` and spot-checks return **302 → `https://room.trydemigod.com/`** with 0 B — that redirect *is* the entry door's home behaviour and is recorded, never followed. On `app`, 200 with 80,079 B. |
| `join` | `/join` | slow | Join page (200, ~6 KB on both doors spot-checked). |

Rules for every leg:
- GET only. No auth, no cookies, no POST. Redirects **never followed** (`redirect: manual` equivalent — curl without `-L`); a 3xx is a result, recorded with `redirect_url`.
- Per-leg timeout: 10 s fast tier, 15 s slow tier (door-monitor's 15 s precedent for the slow set).
- Response body is captured only for `version` and `ready` (both ≤ ~250 B; hard cap 4 KB, truncate-and-flag beyond it) and parsed for the fields in the schema (§4). For `receipts`/`home`/`join` the body is discarded after counting bytes (`-o /dev/null` equivalent at the worker); only `body_bytes` is stored.
- **Stop conditions (fleet discipline, door-monitor precedent):** any leg answered **429** → abort the cycle immediately, emit the legs completed so far plus a `ratelimit` marker record, and suspend capture for 15 minutes (driver checks the checkpoint before each cycle, §5.4). Any leg answered **403** → same stop-and-mark treatment (a 403 to an unauthenticated GET prober most likely means the prober itself is being WAF-blocked; continuing is both impolite and blind). A GitHub 403/429 is out of scope here — this capture never touches GitHub.

## 2. Measurement method

**Chosen: one `curl` subprocess per leg**, orchestrated by a worker process that writes nothing (§5). The worker spawns, per leg:

```
curl -sS -o /dev/null --max-time <10|15> -A "fleet-incident-telemetry/1 (UT-4)" \
  -w '%{json-template}' <url>
```

where `%{json-template}` is an **explicit field template** (below), *not* `%{json}`: this lane verified live that `curl -w '%{json}'` on this VM emits the full TLS certificate text (a multi-KB `certs` blob) per request — unusable as a record source. Explicit template (single line, worker parses it as JSON):

```
{"http_code":%{http_code},"time_namelookup":%{time_namelookup},"time_connect":%{time_connect},"time_appconnect":%{time_appconnect},"time_starttransfer":%{time_starttransfer},"time_total":%{time_total},"size_download":%{size_download},"remote_ip":"%{remote_ip}","http_version":"%{http_version}","redirect_url":"%{redirect_url}"}
```

For `version`/`ready` legs the worker runs the same command without `-o /dev/null`, capturing the small body on stdout separately from the `-w` block (curl writes the `-w` block after the body; worker splits on the final `{`).

Verified environment: `curl 8.5.0 (x86_64-pc-linux-gnu) libcurl/8.5.0 OpenSSL/3.0.13 … nghttp2/1.59.0` on this VM. UT-4B must pin and record `curl --version`'s first line in the dataset header record; a curl version change mid-capture is a dataset annotation event, not a silent change.

### 2.1 Why curl, not Node https/tls instrumentation

1. **No connection reuse, ever.** Each leg is a fresh process: no keep-alive pool, no agent socket reuse, no in-process DNS cache. A long-lived Node prober with a default agent reuses sockets, collapsing connect/TLS to ~0 on later legs and making phase values depend on leg order — exactly the confound this dataset exists to remove. (OS-level DNS caching still applies and is declared in §6 limits.)
2. **One timing implementation, documented semantics.** libcurl's `time_*` values are cumulative timestamps from a single monotonic clock with published meanings. Node would require hand-instrumentation across `lookup` / `socket` / `secureConnect` / `response` events, where DNS timing is conflated with libuv threadpool scheduling and TLS timing with event-loop lag — three separate hand-rolled error surfaces, different in every reimplementation.
3. **Repeatability by other people.** The acceptance test of this design is that Codex, or any seat, can paste the §7 spot-check command and reproduce the same field set with the same meanings. A bespoke Node timing harness cannot be re-run by hand; this curl command was run by hand, by this lane, to produce §7.
4. **Spawn overhead is outside the measurement.** libcurl's timers start inside the process; process-spawn cost (~ms) lands in cycle wall-time (recorded as cycle duration), never inside a phase.
5. **It keeps the fetcher disposable.** Under the F2 latch model (§5) any process that fetches is write-poisoned. A curl child is the most disposable fetcher there is: it writes nothing, ever, and its only output channel is the pipe to its parent.

Rejected alternative, for the record: Node `fetch` (the door-monitor's method) is fine for status/latency alerting — door-monitor needs one number (total ms) and a status. It exposes **no** phase decomposition at all, which is the entire point here. Door-monitor remains the alerting tool; this capture is the forensic dataset. They coexist; neither replaces the other.

### 2.2 Phase derivation (exact)

libcurl returns cumulative seconds (float, µs resolution). The worker converts each to integer ms (`round(s × 1000)`) and stores **both** the cumulative values and the derived phases, so any derivation can be re-checked from the record itself:

| Stored field | Derivation |
|---|---|
| `dns_ms` | `time_namelookup × 1000` |
| `tcp_ms` | `(time_connect − time_namelookup) × 1000` |
| `tls_ms` | `(time_appconnect − time_connect) × 1000` |
| `wait_ms` | `(time_starttransfer − time_appconnect) × 1000` — server time before first byte: Worker execution + any DO/RPC wait + queueing, as one black box (§6) |
| `xfer_ms` | `(time_total − time_starttransfer) × 1000` |
| `total_ms` | `time_total × 1000` |

Failure handling in derivation: if a cumulative field is `0` because the phase never completed (e.g. TLS failure ⇒ `time_appconnect = 0`), every phase at or after the failed stage is stored as **`null`, never 0**, and the record carries `curl_exit` (worker's spawn status) plus `error` (first line of curl stderr, truncated to 200 chars). A timeout record is data — an incident window full of timeouts must not become a hole in the dataset shaped like the incident.

### 2.3 Clock source and timestamps

- **Phase durations** come from libcurl's monotonic clock — immune to wall-clock steps.
- **Record timestamps**: `ts_ms` = integer milliseconds since the Unix epoch (UTC), taken by the *worker* via `Date.now()` immediately before spawning that leg's curl (per-leg, not per-cycle: a sequential cycle's legs are seconds apart, and §7 shows totals up to ~2.8 s). The supervisor adds its own `written_ts_ms` to the cycle's trailer record; worker-vs-supervisor clock disagreement > 1 s is impossible on one host and would itself be a defect signal.
- Host wall clock is the VM's NTP-disciplined clock (systemd-timesyncd). Absolute offset error cancels in every analysis this design supports: all decomposition is *within-window, cross-phase / cross-leg / cross-door* comparison on the same clock. ISO-8601 strings are derived at analysis time only; the stored primary is always `ts_ms`.

## 3. Cadence and request volume

### 3.1 The requirement

5177's window was 12 minutes (02:39–02:51Z). To decompose a window of that length an analyst must be able to (a) timestamp onset and recovery, (b) split the window into sub-intervals and compare phase *medians* per sub-interval (single samples are too noisy — §7's healthy totals range 0.55–2.77 s), and (c) do so per leg, because the decomposition *is* the cross-leg comparison.

- At **60 s** cadence: 12 samples/leg/window → 3-min bins hold 3 samples each. A median of 3 is a coin-flip in this noise. Insufficient.
- At **30 s** cadence: 24 samples/leg/window → 3-min bins hold 6, 1-min bins hold 2. A median of 6 separates the effects in §7 cleanly (wait/TLS move by hundreds of ms; TCP moves by < 4 ms). Onset/recovery located to ±30 s. **Sufficient, and the coarsest cadence that is.**
- At 10 s: 72 samples — better bins, 3× the volume, and the marginal analytic gain is small because consecutive samples are autocorrelated through the same edge/DO state. Rejected as the standing cadence.

### 3.2 Tiered cadence (the specification)

| Tier | Legs | Cadence | Requests/day |
|---|---|---|---|
| Fast | `version`, `ready` × 2 doors = 4 | **every 30 s** | 4 × 2,880 = **11,520** |
| Slow | `receipts`, `home`, `join` × 2 doors = 6 | **every 5 min** | 6 × 288 = **1,728** |
| **Total** | | | **13,248 requests/day** |

Bytes: fast legs are ~200 B each (≈ 4.6 MB/day of body). Slow cycles move ≈ 123 KB (receipts 15,436 × 2 + home 80,079 + 0 + join ~6 KB × 2) × 288 ≈ **35 MB/day**, dominated by the `app` home page. That is the polite-volume statement: ~13.2 k small GETs/day against a production door that serves the same pages to the public, no auth, no writes, 429/403 = immediate stop (§1). For scale: door-monitor's hourly 10-probe pass is 240/day; this capture is deliberately ~55× that because its purpose — window decomposition — is the one door-monitor cannot serve at any hourly cadence. If a future operator judges 13.2 k/day impolite, the first cut is `home` to every 15 min (−1,152 req/day, −23 MB/day), never the fast tier: the fast tier *is* the instrument.

Honest tier asymmetry: in a 12-minute window the slow tier yields only 2–3 samples/leg — enough to state gross state ("receipts stayed 200, ~15.4 KB throughout") and **not** enough to decompose. The design's decomposition claims (§6) rest on the fast tier; slow-tier legs are context.

Within a cycle, legs run **sequentially in fixed order** (`version`, `ready` first in the fast tier) so the decomposition-critical pair has the least intra-cycle skew; each leg still carries its own `ts_ms`. Parallelising legs would tighten skew but make the phases compete for the same VM CPU/egress — sequential is the repeatable choice.

**Explicitly out of scope for v1:** incident-triggered burst cadence (e.g. 10 s sampling for 5 min after a `ready` non-200). It would sharpen onset capture, but it multiplies request volume precisely when the origin is distressed, and the trigger state machine is build surface UT-4B does not need. Named here so UT-4C's operator can propose it as a v2 with data, not as an accident.

**Driver contract:** the capture is *not* a daemon. An external driver (cron at 1-minute granularity invoking the fast cycle twice per invocation is **not** acceptable — cycle freshness rules in §5 require one fresh top-level process per write cycle; the correct driver shape is: one invocation per 30 s fast cycle, e.g. a systemd timer / cron-driven wrapper that itself spawns a fresh supervisor per cycle, or two offset cron entries). UT-4C picks the concrete driver; the contract it must satisfy is §5.1 rule 1. Slow-tier due-ness is decided by the checkpoint file (§5.3): a fast cycle runs the slow tier too when `last_slow_ts_ms` is ≥ 5 min old.

## 4. Storage and record schema

### 4.1 Files (all under the wave dir — standing capture state never lives in a scratch dir)

```
~/workspace/wave-2026-10-28-useful-trials/lanes/UT-4C/data/
  telemetry-2026-10-29.jsonl        # one file per UTC day, append-only
  telemetry-2026-10-30.jsonl
  checkpoint.json                   # small state file, atomic-swap (§5.3)
```

Promotion path (if the format is adopted beyond the trial): same schema, same tool, state dir moves to `~/workspace/fleet-tools/state/incident-telemetry/` per fleet convention — a config change, not a redesign. Dataset growth ≈ 13,248 records/day × ~420 B ≈ **5.6 MB/day**; a 24 h trial window (UT-4's window) is ~6 MB. Retention for the trial: keep everything; no compaction, no summarisation — the raw dataset is the artefact handed to Codex (UT-4E).

### 4.2 Record schema (one JSON object per line)

Leg record:

```json
{"v":1,"type":"leg","ts_ms":1760000000000,"cycle_id":"20261029T053000Z-0001","door":"app","leg":"ready","tier":"fast","url":"https://room.trydemigod.com/api/ready","http_code":200,"dns_ms":3,"tcp_ms":0,"tls_ms":312,"wait_ms":236,"xfer_ms":0,"total_ms":551,"body_bytes":194,"remote_ip":"…","http_version":"2","redirect_url":"","curl_exit":0,"error":null,"ready_status":"ok","do_status":null,"do_timeout_ms":null,"do_ms":null,"src_rev":"2d72bb7f","build_id":"2026-10-29T05:36:10.253Z"}
```

Field rules:
- `ready_*` / `do_*` fields appear only on `ready` legs, parsed from the body: `ready_status` = body's `status`; `do_status` = body's `do.status`; `do_timeout_ms` = body's `do.timeoutMs`; `do_ms` = body's `do.ms`. When the body shows the degraded shape, these four fields carry the server's own DO verdict (`"timeout"`, `1000`, `1000`) alongside our external timing — the single most valuable correlation in the dataset.
- `src_rev` (first 8 of `sourceRevision`) and `build_id` appear only on `version` legs — this pins every cycle to the deployed build, so a deploy flip *inside* an incident window is visible in the dataset itself instead of being a confound discovered later. (Spot-check: `src_rev` `2d72bb7f` matched the coordinator's production read in wave STATE.md exactly.)
- Cycle trailer record, one per cycle, written last: `{"v":1,"type":"cycle","cycle_id":…,"ts_ms":<cycle start>,"written_ts_ms":<supervisor write time>,"legs":4|10,"wall_ms":<cycle wall time>,"slow_ran":false}`.
- Marker records share the file: `{"v":1,"type":"ratelimit",…}` / `{"v":1,"type":"write_refused",…}` (§5.4) / `{"v":1,"type":"gap","from_ts_ms":…,"to_ts_ms":…,"missed_cycles_est":…}` (§5.4).
- Dataset header: the first line of each daily file is `{"v":1,"type":"header","tool":"incident-probe","tool_version":"1.0","curl_version":"curl 8.5.0 …","host":"<vm hostname>","started_ts_ms":…}`.

## 5. Episode-safe write path (the section deploy-watch's death makes mandatory)

The EPERM episode is **live**, and its model is settled (FIGURE-OUT F2, F2-06 composition verdict, >790 attempts): executing `git`, executing `python3`, performing an HTTPS `fetch`, or importing any module from the `fleet-tools/` tree **arms a latch on the whole process subtree**; every later write in that subtree fails for the subtree's life; failure *signature* varies (Node reports `EPERM`; python buffered writes and shell write-new+rename report **exit 0 while landing 0 bytes**); a fresh subtree starts clean; retries inside a latched subtree can never work (10/10 jittered retries failed, both classes). A telemetry capture is the worst-case victim of this gate: *its probing is itself an arming event*, so a naive single-process prober-that-appends is latched by its own first cycle and then silently records nothing — deploy-watch's failure shape exactly. The write path below is therefore not a detail; it is the design.

### 5.1 Rules (binding on UT-4B)

1. **Fresh top-level process per write cycle.** Each cycle is executed by a brand-new supervisor process tree, spawned by the external driver (§3.2), which exits at cycle end. No daemon, no `setInterval` loop, no long-lived parent that "also writes". If a cycle's subtree gets latched by anything unforeseen, exactly one cycle is affected and the next cycle starts clean by construction.
2. **Writer-as-parent, fetcher-as-child (F2-07 §1.1 topology).** The **supervisor** is the scheduler/driver-invoked entry point. In its entire history it must: spawn no `git`, spawn no `python3`, perform no network fetch, and import **nothing** from `fleet-tools/` and no non-builtin module — Node builtins only, everything inlined in the one file. The supervisor spawns the **worker** as a child (`node <tool> --worker <cycle-spec>`, builtins only in the worker too — it needs `child_process` for curl and nothing else). The worker does all the fetching (via curl grandchildren), assembles the cycle's JSONL lines, and emits them on **stdout** — the worker writes no file, ever. The supervisor reads the worker's stdout pipe to EOF, and only then writes. Rationale, per F2-06/F2-07: latch descent runs downward (a poisoned parent's children fail 15/15), while a parent merely *receiving* a child's stdout was never shown tainted by receipt alone — bytes over a pipe from a live process are the measured clean leg. The inversion (writer as parent, tainted work as child) is the single structural move; "spawn a writer child from the prober" is the exact anti-pattern.
3. **The atomic-write pattern is inlined, never imported.** The supervisor's file contains its own copy of the algorithm (§5.3) and imports no helper. Importing `fleet-tools/atomic-write.mjs` in a writing process is a measured arming event (0/6, F2-02) — a build that imports it has disabled itself before its first write. UT-4B acceptance includes the F2-07 T5 grep: no `fleet-tools/` import anywhere in the tool, no `atomic-write` reference outside comments explaining this rule.
4. **Dataset writes are appends; checkpoint writes are atomic swaps; never the reverse.** Appending under refusal fails safe (target byte-identical — F2-01/F2-03). The dataset file is **never** rename-swapped and never overwritten: the shell/rename shape without readback is the proven silent-truncation shape (exit 0, target 0 B in 19/20 hard trials, F2-03). Rename-swap is used only for the tiny `checkpoint.json`, only with the full readback algorithm (§5.3), where the payload is regenerated deterministically each cycle so a lost swap is a lost hint, not lost data.
5. **Exit 0 is never evidence.** Every write is verified by the supervisor re-reading the target (§5.3). A write whose readback does not match is a failed write, full stop.

### 5.2 The dataset append, exactly

Per cycle, the supervisor holds the cycle's lines as one string `payload` (leg records + trailer, each `\n`-terminated). Then:

1. `sizeBefore` = size of today's JSONL (0 if absent; create the day's file with the header line as the first append if absent).
2. `appendFileSync(path, payload)` — plain append, builtins only.
3. Verify: re-stat → size must equal `sizeBefore + Buffer.byteLength(payload)`; read back exactly the appended byte range and require its sha256 to equal sha256(`payload`) computed in-process.
4. Any throw (`EPERM`/`EACCES`) or verify mismatch → §5.4 fallback. **No retry in this subtree** — not once, not with jitter (F2-06 §5.2: retry by state change, not repetition). The *next cycle's fresh process* is the retry.

### 5.3 Checkpoint write — the inlined atomic pattern (UT-4B copies this shape, not a library)

`checkpoint.json` carries `{last_cycle_ts_ms, last_slow_ts_ms, last_cycle_id, suspended_until_ts_ms, last_write_status}`. Write algorithm, inlined in the supervisor:

```
function atomicSwap(target, content):            # builtins only: fs, crypto
  tmp = target + ".tmp-" + process.pid
  fd = openSync(tmp, "w"); writeSync(fd, content); fsyncSync(fd); closeSync(fd)
  back = readFileSync(tmp, "utf8")
  if sha256(back) != sha256(content): unlink tmp; throw EVERIFY
  renameSync(tmp, target)
  try: dirfd = openSync(dirname(target), "r"); fsyncSync(dirfd); closeSync(dirfd)   # best-effort
```

A refused checkpoint write is **not** fatal and follows §5.4's logging, but the dataset append (§5.2) is attempted first and independently: record-before-state ordering (F2-07 §1.1.6) — the data lands or falls back before any state advances.

### 5.4 Failure surfaces — nothing dies silently

- **Append refused / verify failed:** the supervisor (a) writes the cycle's exact payload lines to its own **stdout**, unprefixed, so the invoking surface (cron log / UT-4C operator / agent file tools — the measured always-clean write route, F2-06 §5.1.6) can file them verbatim into the dataset; (b) writes one line to **stderr**: `WRITE-REFUSED incident-probe cycle=<id> code=<EPERM|EACCES|EVERIFY> lines=<n> bytes=<n>`; (c) exits **2**. The cycle is *recovered-or-labelled*, never silently absent: if the stdout payload is filed later it joins the dataset out of order but timestamp-true (every record carries its own `ts_ms`; analysis sorts, appends do not need to be chronological).
- **Gap self-report:** at startup each cycle, the supervisor reads the tail of today's (and if needed yesterday's) dataset file; if the newest `cycle` trailer is older than **2× the fast cadence (60 s)** relative to cycle start, the first record it writes for this cycle is a `gap` marker naming `from_ts_ms`, `to_ts_ms`, and the estimated missed-cycle count. Dataset holes thus announce their own size and bounds in-band — an analyst decomposing a window can see whether the window is measured or missing, which is the difference between a dataset and a rumour.
- **Rate-limit suspension:** on a `ratelimit`/`forbidden` marker the supervisor sets `suspended_until_ts_ms = now + 15 min` in the checkpoint payload it *attempts* to write; if that write is itself refused, the stdout fallback carries the marker and the driver-level rule stands: UT-4C's operator checks for a recent marker in the dataset/stdout before resuming. Belt and braces, both named, because the checkpoint is exactly the file most likely to be unwritten in the bad case.
- **Worker failure** (curl absent, worker crash): supervisor emits a `type:"tool_error"` record payload through the same append/fallback path and exits 2. A dead instrument must leave a corpse in the dataset.

### 5.5 Residual risk, stated (not hidden)

F2-06 §4.1 leaves the latch's scope key unmeasured (exec-subtree vs process-group vs session were never separated; ~12 trials named as the closing set). If the key proves broader than the subtree, even the §5.1 topology could be refused, and the surviving architecture is the one already specified as fallback: payloads reach the dataset via stdout + the invoking surface's file tools (§5.4). The design degrades to that by decision, not by rediscovery — and crucially, **the failure mode in every branch is a labelled gap plus a stdout payload, never a silently truncated or silently absent dataset**. That property, not a promise that writes always land, is what "survives the episode" means here. UT-4B's acceptance includes F2-07's T1 analogue: arm the latch inside the supervisor's subtree before invocation (spawn `git --version` from a test wrapper), run one cycle against the live doors, and assert: dataset byte-identical, no `.tmp-` litter, exit 2 with the `WRITE-REFUSED` stderr line and the full payload on stdout, and the next fresh cycle landing exactly once.

## 6. The decomposition claim — what this can and cannot support

This section is written for the future incident readout (UT-4D) and for Codex, who asked for exact sources and negative results. Language discipline is part of the spec: a readout may say **"consistent with"** where this table says so, and may not upgrade it.

### 6.1 What a readout CAN say

Given a window with fast-tier coverage (24 samples/leg/door per 12 min):

| Observed pattern (phase medians per 3-min bin vs the window's own baseline hours) | Supported statement |
|---|---|
| `wait_ms` inflates on both doors, `dns/tcp/tls_ms` flat, `version` **and** `ready` inflate together | "Time-before-first-byte inflated server-side across the board — Worker execution and/or everything it waits on. Not network, not DNS, not TLS/edge termination, not transfer." |
| `wait_ms` inflates on `ready` while `version`'s `wait_ms` stays flat in the same cycles, both doors | "The inflation is specific to the DO-touching path, not generic Worker slowness." Corroborated in-band when `ready` bodies flip to `do_status:"timeout"` / HTTP 503 while `version` stays 200 — the server's own DO probe reporting its 1000 ms timeout. **Consistent with DO serialisation** (a single-threaded DO event loop queueing requests behind slow work): queueing inflates wait-before-first-byte on DO legs exactly this way. |
| `tls_ms` inflates, `wait_ms` flat | "Edge/TLS-termination or path problem, not application." |
| `dns_ms`/`tcp_ms` inflate | "Name-resolution / network-path problem, not application." (Expected to be rare and small — spot-check TCP phase never exceeded ~4 ms.) |
| `xfer_ms` inflates on `receipts`/`home` only, `wait_ms` flat | "Body/transfer problem (size change, cache miss, bandwidth), not compute." |
| One door inflates, the other flat in the same cycles | "Door/path-specific (entry Worker / its route), not the shared backend." Both doors front the same production build (spot-check: identical `sourceRevision`, identical receipts bytes) — that shared-backend fact is what makes the cross-door comparison a discriminator at all. |
| Any of the above, as timing facts | Onset and recovery of the window located to ±30 s, and the deploy context fixed in-band (`src_rev`/`build_id` per cycle). |

### 6.2 What a readout CANNOT say — named limits

1. **It cannot split DO dispatch vs constructor vs handler/storage time.** All of it — plus Worker CPU, plus DO RPC transit, plus any queueing — sits inside the single black box `wait_ms`. That split is precisely 5177's ask, and it still requires Cloudflare stored telemetry under John's authorization (Workers/DO logs and metrics). This capture narrows an incident to "server-side, before first byte, on these legs, from this minute to that minute" and **no further**. Any readout that names a DO-internal phase from this dataset alone is overclaiming and must be bounced.
2. **DO serialisation is a consistency claim, never a proof from this data.** Worker CPU saturation, DO storage latency, and DO queueing all inflate `ready`'s `wait_ms` identically from outside. The dataset can *exclude* causes (network, TLS, transfer, generic Worker) — exclusion is its real power — and the survivor set may be a single member; even then the readout says "consistent with, alternatives excluded as follows", listing them.
3. **`version` as the non-DO control is a working assumption, not a verified fact.** If `version` is ever observed co-moving with `ready` under a known DO-only fault (or its handler is later shown to touch a DO), the `ready`-only discriminator in §6.1 row 2 collapses to row 1's weaker claim. The dataset preserves the raw material to re-derive either way; UT-4D must state which row it is standing on.
4. **GET surface only.** Incidents that manifest on authed, POST, WebSocket, or room-interior paths are visible here only insofar as they also slow the public GET legs. A clean dataset does not prove a clean product.
5. **One vantage point.** All probes originate from this VM, whose egress traverses a local proxy (spot-check: TLS certificates are issued by a sandbox egress CA, and connect phases of ~0.1–4 ms show the first hop is local). Absolute phase values therefore describe *this VM's path*, and TLS/connect noise from the egress path is a standing confound. The mitigations are structural — within-window comparisons, both-door agreement, and phase-*ratio* reasoning — not eliminative. A second vantage point (another host) is the real cure and is out of scope for this trial.
6. **DNS phase includes OS cache hits.** Sub-millisecond `dns_ms` readings (spot-check minimum 0.6 ms) are cache answers, not resolver measurements; the dataset cannot measure authoritative DNS behaviour and a readout must not claim it does.
7. **No per-request correlation.** Without auth or header cooperation from the origin, no record here can be tied to a specific room, DO instance, or user request. The dataset describes the doors' aggregate behaviour, full stop.

### 6.3 Kill-criterion check (from the UT-4 charter)

- "Probe cannot separate phases" — **does not fire**: §7.
- "Write path cannot survive the EPERM episode" — **does not fire as a blocker**: §5 specifies a topology whose worst case is a labelled gap + stdout-recoverable payload. It fires as a *permanent design constraint*: any UT-4B shortcut back to a single-process prober-writer re-opens the blocker and must be treated as a failed build, not a simplification.

## 7. Live spot-check (executed by this lane, 2026-10-28 ~22:50–23:05 PT)

Method, run by hand, exactly the §2 method (this is the repeatability proof — anyone can re-run it):

```
curl -s -o /dev/null --max-time 15 \
  -w "code=%{http_code} dns=%{time_namelookup} tcp=%{time_connect} tls=%{time_appconnect} ttfb=%{time_starttransfer} total=%{time_total} bytes=%{size_download}\n" \
  <door-base><leg>
```

Three batches: two full 10-leg cycles, then a focused batch of 3 repeats × (`version`, `ready`) × 2 doors. **32 leg probes total.** Derived phases below use §2.2 (tcp/tls/wait are differences of the cumulative curl fields). All values ms.

### 7.1 Cycle 1, full matrix (derived phases)

| Door / leg | code | dns | tcp | tls | wait | xfer | total | bytes |
|---|---|---|---|---|---|---|---|---|
| app /api/version | 200 | 10.7 | 2.7 | 491.6 | 371.8 | 0.1 | 876.8 | 207 |
| app /api/ready | 200 | 2.9 | 0.1 | 311.9 | 236.1 | 0.1 | 551.2 | 194 |
| app /api/public/receipts | 200 | 0.6 | 0.1 | 230.2 | 751.1 | 54.1 | 1036.2 | 15,436 |
| app / | 200 | 8.0 | 0.2 | 467.0 | 620.3 | 125.0 | 1220.5 | 80,079 |
| app /join | 200 | 0.6 | 0.1 | 156.9 | 678.6 | 54.4 | 890.6 | 6,057 |
| entry /api/version | 200 | 2.8 | 0.2 | 303.4 | 834.4 | 41.2 | 1181.9 | 207 |
| entry /api/ready | 200 | 2.3 | 0.7 | 415.4 | 1040.3 | 0.1 | 1458.7 | 195 |
| entry /api/public/receipts | 200 | 6.4 | 0.2 | 334.5 | 458.7 | 19.4 | 819.2 | 15,436 |
| entry / (→ /room/) | 302 | 1.7 | 0.2 | 400.8 | 562.1 | 1.6 | 966.3 | 0 |
| entry /join | 200 | 3.5 | 0.4 | 164.1 | 697.9 | 52.3 | 918.1 | 6,102 |

Cycle 2 totals (same command, minutes later) for variance context: app version 1290.4 · ready 1212.6 · receipts 1681.4 · home 1139.9 · join 1398.4; entry version 1131.4 · ready 1271.2 · receipts 1157.7 · home 1326.5 (302) · join 965.1. Entry home's redirect target, verified directly: `https://room.trydemigod.com/`.

### 7.2 The focused batch caught a live ready-flap

Of the 12 focused `version`/`ready` probes, **3 returned 503 on `ready`** (entry rep 1: total 1927.1, wait 1466.0; entry rep 2: total 1830.1, wait 1515.6; app rep 3: total 1763.2, wait 1304.3) while every `version` probe in the same minutes stayed 200. Degraded `ready` bodies are 182 B vs 194–195 B healthy — `body_bytes` alone discriminates the state. A direct body read minutes later confirmed the mechanism in the server's own words: `ready` → `{"status":"degraded",…,"durableObject":{"ready":false,"status":"timeout"},"do":{"status":"timeout","timeoutMs":1000,"ms":1000}}`, while `version` simultaneously returned `sourceRevision 2d72bb7f…` (matching wave STATE.md's production read) with `buildId 2026-10-29T05:36:10.253Z`. This is §6.1 row 2's pattern, observed live during the design spot-check: DO-path-specific wait inflation with a healthy control leg. (Consistent with DO distress; per §6.2.2 this design does not claim more than that.)

### 7.3 Phase separation — the verdict the kill criterion turns on

Across all 32 probes: `dns_ms` 0.6–100.6 (one 100.6 outlier; median ≈ 3) · `tcp_ms` (phase) 0.1–4.0 · `tls_ms` (phase) 157–1067 · `wait_ms` 151–1665 · `total_ms` 551–2773. The phases occupy different orders of magnitude and move **independently**: the largest DNS reading (100.6, cycle-2 entry version) coincides with an unremarkable TLS phase (419); the largest TLS phase (1061.1, focused rep-3 app version, total 2773.2) pairs with a wait of 1665.3 on a *200* response; the 503 `ready` probes show ordinary TLS (313–456) with wait dominating. Timing does **not** collapse into one number. **Kill criterion "cannot separate phases" does not fire.** The honest shadow of this result: healthy-state variance is large (totals 0.55–2.77 s from this vantage), which is why §3 mandates 30 s sampling and median-of-6 bins, and why no readout may reason from single samples.

## 8. What UT-4B builds (acceptance checklist, handed over)

1. One file, `incident-probe.mjs`, living **outside** `fleet-tools/` for the trial (lane dir `~/workspace/wave-2026-10-28-useful-trials/lanes/UT-4B/`), Node builtins only, inlined atomic pattern, no imports beyond `node:*`. Supervisor/worker split per §5.1 behind `--worker`; CLI: `node incident-probe.mjs cycle [--data-dir <dir>] [--dry-run]` (dry-run prints payload, writes nothing).
2. Curl invocation, phase derivation, null-on-incomplete rule, schema, tiers, stop conditions exactly per §1–§4. `curl --version` first line and hostname go in each daily header.
3. Tests, all offline except one live smoke: (a) derivation unit tests from recorded curl outputs (healthy, 503-with-body, TLS-failure⇒nulls, timeout); (b) schema test on a fixture cycle; (c) **latched-subtree test** (§5.5): dataset byte-identical, exit 2, `WRITE-REFUSED` on stderr, full payload on stdout, next fresh cycle lands once; (d) gap-marker test (backdate the trailer, expect a `gap` record); (e) ratelimit test against a fixture (a local HTTP server or a stubbed worker emitting 429 ⇒ cycle aborts, marker lands, suspension honoured); (f) live smoke: 3 real cycles produce schema-valid records for all 10 slow legs + fast legs.
4. UT-4C then runs it for the 24 h trial window under the §3.2 driver contract, and UT-4D's readout uses §6's table and language discipline, stating which §6.1 row it stands on.

## 9. verify-claim-checkable claims

- Door bases and probe set are door-monitor v1.1's verbatim: bases `https://room.trydemigod.com` and `https://www.getdasha.com/room`; legs `/`, `/api/version`, `/api/ready`, `/api/public/receipts`, `/join` (`fleet-tools/README-door-monitor.md`, Probes table).
- Spot-check counts: 32 curl phase probes (2×10 full cycles + 12 focused); statuses 27× 200, 2× 302 (both entry home), 3× 503 (all `ready`); receipts body 15,436 B on both doors in both full cycles; entry home 302 target `https://room.trydemigod.com/` read directly.
- The degraded `ready` body, `version`'s `sourceRevision` (`2d72bb7f…`, matching wave STATE.md's production read) and `buildId` (`2026-10-29T05:36:10.253Z`) were read live by this lane during the spot-check window quoted in §7.
- F2 latch facts cited (arming events incl. `fetch` and `fleet-tools/` imports; ≥60 s in-subtree persistence; fresh subtree clean; shell rename-swap silent truncation 19/20; in-latch retries 0/10×2) are F2-06 §1/§2's graded counts; the writer-as-parent topology and T1/T5 acceptance shapes are F2-07 §1.1/§6.
- Daily volume arithmetic: fast 4 req × 2,880 cycles = 11,520; slow 6 req × 288 cycles = 1,728; total 13,248 req/day (§3.2).
- This lane made no room posts, no production writes, and no GitHub calls; all production contact was unauthenticated GET via curl. Scratch dir `~/workspace/wave-2026-10-28-useful-trials/scratch/UT-4A` is deleted before this lane reports done.
