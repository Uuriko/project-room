# UT-4D — PROOF: independent verification of UT-4C's telemetry dataset

**Lane:** UT-4D (critic half of the author+critic pair for UT-4C). **Close state: FILED.**
**Method:** every number below was recomputed from the raw file only, with a throwaway Node analyser written for this lane (scratch, deleted at close). DATASET.md's numbers were treated as claims, never as inputs. Statistics follow DATASET.md's own stated definitions: median = standard median, p95 = nearest-rank, over the stored per-leg phase fields. No room posts, no GitHub calls, no new production probing — the filed dataset and UT-4C's capture logs only.
**Subject qualified:** `lanes/UT-4C/data/telemetry-2026-10-29.jsonl` as decoded below, plus DATASET.md's claims about it and DESIGN.md (UT-4A) §6's language rules. Nothing is claimed about production state outside this window, and nothing about DO internals (§6 below).

## 1. File integrity — CONFIRMED

| Claim | Recomputed | Verdict |
|---|---|---|
| 205,165 bytes | 205,165 bytes | CONFIRMED |
| sha256 `ffbe429d0c612ec4d1987550c60798d73c2dc91b27a332d2b52c84643b673c0c` | identical hash, computed independently | CONFIRMED |
| 441 lines = 1 header + 400 legs + 40 trailers | record-type census: exactly `{header: 1, leg: 400, cycle: 40}` and no other types | CONFIRMED |
| Every trailer says `legs: 10` | all 40 trailers `legs: 10`, all `slow_ran: true`; each trailer's cycle_id matches exactly 10 leg records; 40 distinct cycle_ids | CONFIRMED |
| No gap records | zero `gap`, `ratelimit`, `forbidden`, `tool_error`, or `write_refused` records in the file | CONFIRMED |
| Span 2026-10-29T06:00:53.129Z – 06:22:35.560Z | header/cycle-1 start 2026-10-29T06:00:53.129Z; first leg 06:00:53.262Z; last leg 2026-10-29T06:22:35.560Z; last cycle start 06:22:19.604Z | CONFIRMED (span is first-cycle-start → last leg, exactly as DATASET.md itemises it) |
| Header: `incident-probe` 1.0, curl 8.5.0, host `htch-runtime` | header record carries all three verbatim | CONFIRMED |

## 2. Headline counts — CONFIRMED

| Claim | Recomputed | Verdict |
|---|---|---|
| 503s = 32 of 80 ready legs | 32 leg records with `http_code 503`, all `leg "ready"`, out of 80 ready legs | CONFIRMED |
| app 17/40, entry 15/40 | app 17, entry 15 | CONFIRMED |
| 21/40 cycles contain a flap | 21 distinct cycle_ids among the 503 legs | CONFIRMED |
| 11 cycles flap on both doors | 11 (cycles 0005, 0006, 0010, 0014, 0017, 0025, 0032, 0034, 0035, 0037, 0040) | CONFIRMED |
| Statuses 200×328 / 302×40 / 503×32 | exactly 328 / 40 / 32; no other statuses present | CONFIRMED |
| 302s all `entry/home` | 40/40 are `entry/home` | CONFIRMED |
| Zero curl errors | `curl_exit ≠ 0` on 0 legs; `error` non-null on 0 legs; no null phase fields on any leg | CONFIRMED |
| Flap signature identical on all 32 | every 503 leg: `ready_status "degraded"`, `do_status "timeout"`, `do_timeout_ms 1000`, `do_ms 1000`, `body_bytes 182`, `curl_exit 0`, `xfer_ms 0` — 32/32 | CONFIRMED |
| DATASET.md's 32-row anomaly table | all 32 rows (timestamp, door, cycle, tls/wait/total) match the raw records exactly; no flap omitted, none invented | CONFIRMED |

## 3. Phase separation and the per-surface table — CONFIRMED

- Ready legs answering 200 (n=48): **wait median 490 ms, TLS median 118.5 ms** — exactly as claimed.
- Ready legs answering 503 (n=32): **wait median 1,435.5 ms, TLS median 125.5 ms** — exactly as claimed. Wait ratio 1,435.5 / 490 = 2.93× ("roughly triples" is accurate); TLS moves +7 ms. The phase separation is real in the raw data: the 503 excess lives in `wait_ms`, not in DNS (median 1 ms in both groups), TCP (0 in both), TLS, or transfer (0 in both).
- Per-surface table: all **70 cells** (10 surfaces × tls/wait/total median, p95, total max) recomputed. **Zero cells differ beyond rounding.** DATASET.md prints integers; its convention is round-half-up of exact .5 medians (e.g. app/ready total median 854.5 → printed 855; entry/ready wait median 768.5 → printed 769). With that convention applied, 70/70 cells match exactly, including every p95 and max.

## 4. Worked example, cycle `20261029T060544Z-0010` — CONFIRMED

All four legs match the raw records field-for-field:

| Leg | Claimed | Recomputed |
|---|---|---|
| app/version 06:05:45.117Z, 200 | dns 1, tcp 0, tls 118, wait 466, xfer 1, total 586, `src_rev 2d72bb7f` | identical |
| app/ready 06:05:45.728Z, 503 | dns 1, tcp 0, tls 126, wait 1,637, xfer 0, total 1,764, degraded / timeout / 1000 of 1000 | identical |
| entry/version 06:05:47.508Z, 200 | dns 1, tcp 0, tls 119, wait 690, xfer 54, total 863, `src_rev 2d72bb7f` | identical |
| entry/ready 06:05:48.396Z, 503 | dns 0, tcp 0, tls 160, wait 1,513, xfer 0, total 1,673, degraded / timeout / 1000 of 1000 | identical |

Derived excesses also check: +1,171 ms (app, 1,637 − 466) and +823 ms (entry, 1,513 − 690), as printed. This cycle is a genuine DESIGN §6.1 row-2 pattern: same-cycle, same-door version controls flat while both ready legs flap with the server's own DO-timeout verdict in-band.

**Critic's nuance (does not correct any DATASET.md claim, but bounds it):** cycle 0010 is the *strongest* separation in the window — the app delta (+1,171 ms) is the maximum of all 32 flap deltas. Window-wide, the same-cycle control is usually not flat: flap wait minus same-cycle same-door version wait has median only +280 ms, is negative for 14 of 32 flaps, and the version leg in the same cycle exceeds 1,000 ms wait for 19 of 32 flaps; version wait median is 1,199.5 ms in flap cycles vs 497.5 ms in clean cycles. So row 2 holds cleanly for the worked example, while the window-wide picture also carries a §6.1 row-1 component (server-side wait inflation across the board in flap cycles). DATASET.md does not claim row 2 window-wide — its dataset-wide sentence claims only the ready-200 vs ready-503 wait/TLS split, which is confirmed above — so this is a scoping note for future readouts, not a correction. Per DESIGN §6.2.3, this proof stands on row 2 for cycle 0010 and on row 1 + the ready-specific 503/timeout signature for the window as a whole.

## 5. Deploy flip — CONFIRMED

- `version` legs pin `src_rev 2d72bb7f` / `build_id 2026-10-29T05:36:10.253Z` for cycles 1–21 (21 legs per door) and `src_rev eaa97768` / `build_id 2026-10-29T06:06:55.291Z` for cycles 22–40 (19 legs per door); no cycle mixes revisions. Exactly as claimed.
- First new-rev leg: app/version at **2026-10-29T06:12:19.445Z**, cycle `20261029T061219Z-0022`. Exactly as claimed.
- Flaps on both builds: 15 flap legs pre-flip (cycles 1–21), 17 post-flip (cycles 22–40), including cycle 0022 itself. "Not tied to a single deploy" is supported.

## 6. Interpretation discipline vs DESIGN §6 — CONFIRMED (no overclaim found)

Full-text scan of DATASET.md for causal/proof language (`prov*`, `caus*`, `must be`, `because`, `dispatch`, `constructor`, `handler`, `serialis*`):

- The only DO-internal-phase sentence is the decomposition paragraph, and it reads, verbatim in substance: the pattern "is **consistent with DO serialisation / DO-path distress and does not prove a DO-internal phase** (§6.2.1: dispatch vs constructor vs handler remains behind Cloudflare telemetry under John's authorization — this dataset deliberately does not claim it)." That is exactly §6's permitted language, with the limit named.
- "network, DNS, TLS/edge and transfer are excluded" (worked example) is §6.1's supported exclusion statement for that pattern, and §4 above verifies its premises in the raw data.
- The Class-1 heading "flaps with DO timeout" names the server's own in-band `do_status "timeout"` field, not a DO-internal phase; no dispatch-vs-constructor-vs-handler claim appears anywhere.
- No sentence upgrades "consistent with" to proof, and none claims a cause. **No overclaim to flag.**

## Ancillary DATASET.md claims spot-verified (beyond the assigned six)

- Pacing: start-to-start median 32.799 s (claimed 32.8), min 29.546 (29.5), max 36.765 (36.8) — CONFIRMED.
- Cycle wall: median 12,156.5 ms (claimed 12,157, round-half-up), p95 19,106, max 23,881 — CONFIRMED.
- Class-2 outliers: the five slowest 200 legs match exactly (slowest: entry/join 2026-10-29T06:15:20.930Z, cycle 0027, wait 7,568, total 7,941) — CONFIRMED; all five are wait-dominated.
- Capture logs: `capture-logs/` holds exactly 80 files, all 0 bytes — consistent with the "all cycles exited 0, no WRITE-REFUSED payloads" claim (exit codes themselves leave no trace in empty files, so that part rests on UT-4C's run record; nothing in the filed evidence contradicts it).
- Checkpoint: `data/checkpoint.json` reads `last_cycle_id 20261029T062219Z-0040`, `cycle_seq 40`, `last_write_status "ok"`, `suspended_until_ts_ms 0` — CONFIRMED.

## Dataset-internal rounding note (not a DATASET.md error)

Recomputing stored phase fields from the stored `cum_ms` cumulatives disagrees on 362 of 2,400 phase values, always by exactly ±1 ms, and phase sums deviate from `total_ms` by at most 2 ms (175 legs). This is the expected artefact of DESIGN §2.2 (phases derived from unrounded libcurl floats; cumulatives stored separately rounded). Consequence for future analysts: compute statistics from the stored phase fields — as DATASET.md did — never re-derive them from `cum_ms`.

## PROOF VERDICT

**Yes — with the §6 scope stated, this dataset decomposes a live incident-class window from fleet custody alone.**

From the fleet's own file, with no Cloudflare telemetry and no new authorization, the window 2026-10-29T06:00:53Z–06:22:35Z (40 cycles, ~30 s cadence, 400 legs) is decomposed to this standard: a recurring ready-503 flap class (32/80 ready legs, 21/40 cycles, both doors, both deploys) whose entire excess sits in time-before-first-byte on the DO-touching path, with DNS, TCP, TLS/edge, and transfer excluded on recomputed medians; corroborated in-band by the server's own DO probe reporting its 1,000 ms timeout on every flap; with the in-window deploy flip (2d72bb7f → eaa97768 at cycle 22) pinned in-band so it cannot confound the reading. That is precisely the decomposition UT-4A designed for and the class of window incident 5177 could not be decomposed for.

What it does **not** do, and DATASET.md does not claim: split DO dispatch vs constructor vs handler time (still behind John's Cloudflare authorization, §6.2.1), or prove DO serialisation (it establishes consistency plus exclusions, §6.2.2). Every assigned claim (sections 1–6) is CONFIRMED; there are no CORRECTED or REFUTED items. The two bounds a future readout must carry are §4's nuance (worked-example separation is the window's strongest, not its typical, cycle) and the `cum_ms` rounding note.

## verify-claim-checkable claims

- Dataset file recomputed independently: 205,165 bytes, sha256 `ffbe429d0c612ec4d1987550c60798d73c2dc91b27a332d2b52c84643b673c0c`, census `{header 1, leg 400, cycle 40}`, all trailers `legs: 10`, zero gap/marker records.
- Status census from raw records: 200×328, 302×40 (all entry/home), 503×32 (all ready; app 17, entry 15; 21 cycles, 11 both-door); `curl_exit ≠ 0` on 0 legs.
- Ready split recomputed: 200 legs (n=48) wait median 490 / TLS median 118.5 ms; 503 legs (n=32) wait median 1,435.5 / TLS median 125.5 ms; per-surface table 70/70 cells match DATASET.md after round-half-up; all 32 flap-table rows match exactly.
- Deploy flip recomputed: 2d72bb7f cycles 1–21, eaa97768 cycles 22–40, first new-rev leg 2026-10-29T06:12:19.445Z; flaps 15 pre-flip / 17 post-flip.
- This lane made no room posts, no GitHub calls, and no production probes; all work was local computation over the filed dataset. Scratch dir `~/workspace/ut4d-scratch` is deleted before this lane reports done.

**Spend:** ~0.2 lane-hours of the ~0.6 budget.
