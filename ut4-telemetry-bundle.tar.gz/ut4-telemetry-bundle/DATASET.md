# UT-4C — DATASET: incident-telemetry capture run

**Close state: FILED** (dataset + this summary). Run by UT-4C per UT-4B's handoff (`probe/README.md`, `probe/run-cycle.mjs`) and UT-4A DESIGN §3.2 driver contract. No room posts, no GitHub calls; production contact was the probe's own unauthenticated GETs only.

## Run shape

- One fresh `run-cycle.mjs` invocation per cycle — a separate top-level process for every cycle, never a loop inside one process (F2 latch rule). Each invocation is a full cycle: both doors, both tiers (`run-cycle.mjs` passes `--force-slow`), 10 legs.
- Pacing: ~30 s start-to-start per DESIGN fast cadence (pad after each cycle). Measured from the dataset's cycle trailers: start-to-start interval median 32.8 s, min 29.5 s, max 36.8 s (the excess over 30 s is driver invocation overhead between cycles).
- Stop condition: ≥40 complete cycles or ~45–60 min wall, whichever first. **The cycle-count trigger fired first**: 40 complete cycles in ~21.7 min of dataset time.
- Supervisor stdout/stderr captured per cycle in `lanes/UT-4C/capture-logs/` (`cycle-0001`…`cycle-0040`, `.stdout` + `.stderr`, 80 files). **All 40 cycles exited 0; all 80 capture files are 0 bytes.** There were **no exit-2 WRITE-REFUSED events** (nothing to file verbatim), no exit-3 SUSPENDED events, and checkpoint `last_write_status` is `"ok"` with `suspended_until_ts_ms: 0`. The write-fault episode did not touch this run: the dataset append landed and readback-verified on every cycle, in order, with no `gap` records.

## Dataset identity

| | |
|---|---|
| File | `~/workspace/wave-2026-10-28-useful-trials/lanes/UT-4C/data/telemetry-2026-10-29.jsonl` |
| Bytes | 205,165 |
| sha256 | `ffbe429d0c612ec4d1987550c60798d73c2dc91b27a332d2b52c84643b673c0c` |
| Lines | 441 = 1 header + 400 leg records + 40 cycle trailers |
| Time span (UTC) | First cycle start 2026-10-29T06:00:53.129Z; first leg 2026-10-29T06:00:53.262Z; last leg 2026-10-29T06:22:35.560Z; last cycle start 2026-10-29T06:22:19.604Z |
| Cycles | 40 complete (every trailer reports `legs: 10`, `slow_ran: true`); cycle wall time median 12,157 ms, p95 19,106 ms, max 23,881 ms |
| Tool header | `incident-probe` 1.0; curl 8.5.0 (x86_64-pc-linux-gnu) libcurl/8.5.0 OpenSSL/3.0.13; host `htch-runtime` |

All statistics below were computed from that file (analyzer run over the JSONL after capture closed; median = standard median, p95 = nearest-rank, over non-null phase values; every leg record in this window has non-null phases).

## Per-surface phase statistics (ms; n = 40 legs each)

| Surface | tls median | tls p95 | wait median | wait p95 | total median | total p95 | total max |
|---|---|---|---|---|---|---|---|
| app/version | 113 | 333 | 868 | 2,082 | 1,042 | 2,314 | 2,580 |
| app/ready | 123 | 253 | 688 | 1,469 | 855 | 1,764 | 1,846 |
| app/receipts | 117 | 263 | 741 | 2,156 | 917 | 2,328 | 3,086 |
| app/home | 125 | 308 | 331 | 696 | 638 | 999 | 1,153 |
| app/join | 133 | 337 | 1,075 | 2,342 | 1,267 | 2,486 | 3,568 |
| entry/version | 118 | 234 | 809 | 2,439 | 1,024 | 2,581 | 2,698 |
| entry/ready | 118 | 217 | 769 | 1,663 | 930 | 1,818 | 2,033 |
| entry/receipts | 123 | 366 | 1,103 | 2,722 | 1,396 | 2,840 | 3,683 |
| entry/home | 130 | 313 | 654 | 2,545 | 776 | 2,723 | 3,080 |
| entry/join | 130 | 324 | 780 | 3,722 | 981 | 3,914 | 7,941 |

Status counts across 400 legs: 200 ×328, 302 ×40, 503 ×32. The 302s are all `entry/home` (40/40) — that door's designed redirect behaviour per DESIGN §1, recorded not followed; they are **not** anomalies.

## Anomalies — every one, with timestamps

**Class 1 — `ready` 503 flaps with DO timeout: 32 legs.** Every one has the identical signature: `http_code 503`, `ready_status "degraded"`, `do_status "timeout"`, `do_timeout_ms 1000`, `do_ms 1000`, `body_bytes 182`, `curl_exit 0`, `xfer_ms 0`. That is 32 of 80 ready legs (40%): app 17/40, entry 15/40; 21 of 40 cycles contain at least one flap; 11 cycles flap on **both** doors in the same cycle. Table lists UTC timestamp, door, cycle, tls / wait / total (ms):

| # | UTC | Door | Cycle | tls | wait | total |
|---|---|---|---|---|---|---|
| 1 | 2026-10-29T06:00:55.188Z | app | 20261029T060053Z-0001 | 152 | 1,437 | 1,592 |
| 2 | 2026-10-29T06:01:56.919Z | app | 20261029T060155Z-0003 | 125 | 1,708 | 1,833 |
| 3 | 2026-10-29T06:03:03.005Z | app | 20261029T060301Z-0005 | 121 | 1,180 | 1,301 |
| 4 | 2026-10-29T06:03:05.384Z | entry | 20261029T060301Z-0005 | 117 | 1,742 | 1,860 |
| 5 | 2026-10-29T06:03:35.885Z | app | 20261029T060333Z-0006 | 104 | 1,437 | 1,542 |
| 6 | 2026-10-29T06:03:38.614Z | entry | 20261029T060333Z-0006 | 103 | 1,425 | 1,529 |
| 7 | 2026-10-29T06:05:16.996Z | entry | 20261029T060511Z-0009 | 116 | 1,496 | 1,613 |
| 8 | 2026-10-29T06:05:45.728Z | app | 20261029T060544Z-0010 | 126 | 1,637 | 1,764 |
| 9 | 2026-10-29T06:05:48.396Z | entry | 20261029T060544Z-0010 | 160 | 1,513 | 1,673 |
| 10 | 2026-10-29T06:07:26.420Z | entry | 20261029T060722Z-0013 | 162 | 1,538 | 1,702 |
| 11 | 2026-10-29T06:07:54.402Z | app | 20261029T060753Z-0014 | 143 | 1,433 | 1,579 |
| 12 | 2026-10-29T06:07:57.185Z | entry | 20261029T060753Z-0014 | 97 | 1,615 | 1,713 |
| 13 | 2026-10-29T06:09:02.632Z | entry | 20261029T060858Z-0016 | 102 | 1,663 | 1,767 |
| 14 | 2026-10-29T06:09:33.444Z | app | 20261029T060930Z-0017 | 107 | 1,190 | 1,299 |
| 15 | 2026-10-29T06:09:35.923Z | entry | 20261029T060930Z-0017 | 99 | 1,485 | 1,584 |
| 16 | 2026-10-29T06:12:22.639Z | entry | 20261029T061219Z-0022 | 179 | 1,638 | 1,818 |
| 17 | 2026-10-29T06:13:59.664Z | app | 20261029T061358Z-0025 | 177 | 1,175 | 1,354 |
| 18 | 2026-10-29T06:14:01.965Z | entry | 20261029T061358Z-0025 | 116 | 1,560 | 1,677 |
| 19 | 2026-10-29T06:15:05.768Z | app | 20261029T061504Z-0027 | 176 | 1,338 | 1,520 |
| 20 | 2026-10-29T06:15:38.905Z | app | 20261029T061537Z-0028 | 106 | 1,305 | 1,413 |
| 21 | 2026-10-29T06:16:45.977Z | app | 20261029T061645Z-0030 | 112 | 1,178 | 1,292 |
| 22 | 2026-10-29T06:17:57.583Z | app | 20261029T061754Z-0032 | 202 | 1,179 | 1,382 |
| 23 | 2026-10-29T06:18:01.302Z | entry | 20261029T061754Z-0032 | 172 | 1,302 | 1,480 |
| 24 | 2026-10-29T06:19:01.848Z | app | 20261029T061900Z-0034 | 253 | 1,208 | 1,465 |
| 25 | 2026-10-29T06:19:04.261Z | entry | 20261029T061900Z-0034 | 272 | 1,747 | 2,033 |
| 26 | 2026-10-29T06:19:36.706Z | app | 20261029T061934Z-0035 | 374 | 1,469 | 1,846 |
| 27 | 2026-10-29T06:19:39.109Z | entry | 20261029T061934Z-0035 | 98 | 1,434 | 1,532 |
| 28 | 2026-10-29T06:20:41.241Z | app | 20261029T062039Z-0037 | 97 | 1,221 | 1,319 |
| 29 | 2026-10-29T06:20:43.357Z | entry | 20261029T062039Z-0037 | 189 | 1,395 | 1,585 |
| 30 | 2026-10-29T06:21:48.717Z | app | 20261029T062146Z-0039 | 107 | 1,284 | 1,392 |
| 31 | 2026-10-29T06:22:21.792Z | app | 20261029T062219Z-0040 | 276 | 1,317 | 1,598 |
| 32 | 2026-10-29T06:22:24.792Z | entry | 20261029T062219Z-0040 | 217 | 1,488 | 1,706 |

**Class 2 — latency outliers on 200 legs (wait-dominated).** Slowest leg of the window: `entry/join` 2026-10-29T06:15:20.930Z, cycle `20261029T061504Z-0027` — 200, dns 3, tcp 0, tls 324, **wait 7,568**, xfer 47, total 7,941 ms. Next: `entry/join` 2026-10-29T06:13:37.608Z total 4,304 (wait 4,198); `entry/join` 2026-10-29T06:05:56.752Z total 3,914 (wait 3,722); `entry/join` 2026-10-29T06:18:10.244Z total 3,787 (wait 3,440); `entry/receipts` 2026-10-29T06:13:31.864Z total 3,683 (wait 3,409). All wait-phase, none TLS/DNS/transfer.

**Classes with zero instances:** `gap` records 0; `curl_exit ≠ 0` legs 0; `ratelimit` / `forbidden` / `tool_error` records 0; non-200/non-302/non-503 statuses 0; missing legs 0 (every cycle complete at 10/10).

**In-window deploy flip (in-band, DESIGN §4 prediction):** `version` legs pin `src_rev 2d72bb7f` / `build_id 2026-10-29T05:36:10.253Z` for cycles 1–21 (21 legs per door), then `src_rev eaa97768` / `build_id 2026-10-29T06:06:55.291Z` for cycles 22–40 (19 legs per door); the first new-rev leg is app/version at 2026-10-29T06:12:19.445Z in cycle `20261029T061219Z-0022`. The ready flaps occur on **both** builds (e.g. cycle 0022 itself, post-flip), so the flap pattern is not tied to a single deploy.

## Worked example — one flap, decomposed phase-by-phase

Cycle `20261029T060544Z-0010` (starts 2026-10-29T06:05:44Z), both doors flapping in the same cycle while the control legs stay healthy — DESIGN §6.1 row 2's pattern:

| Leg (UTC) | code | dns | tcp | tls | wait | xfer | total | Server's own verdict |
|---|---|---|---|---|---|---|---|---|
| app/version 06:05:45.117Z | 200 | 1 | 0 | 118 | 466 | 1 | 586 | — (control, `src_rev 2d72bb7f`) |
| app/ready 06:05:45.728Z | **503** | 1 | 0 | 126 | **1,637** | 0 | 1,764 | `ready_status degraded`, `do_status timeout`, `do_ms 1000` of 1000 ms budget |
| entry/version 06:05:47.508Z | 200 | 1 | 0 | 119 | 690 | 54 | 863 | — (control, `src_rev 2d72bb7f`) |
| entry/ready 06:05:48.396Z | **503** | 0 | 0 | 160 | **1,513** | 0 | 1,673 | `ready_status degraded`, `do_status timeout`, `do_ms 1000` of 1000 ms budget |

Decomposition, in DESIGN §6 language: DNS (0–1 ms), TCP (0 ms), TLS (118–160 ms) and transfer (0 ms) are indistinguishable between the flapping legs and their same-cycle, same-door control legs — network, DNS, TLS/edge and transfer are excluded. The entire excess sits in `wait_ms` (+1,171 ms app, +823 ms entry over the same cycle's version control), i.e. time-before-first-byte on the DO-touching path only, corroborated in-band by the server's own DO probe reporting its 1,000 ms timeout. Per §6.1 this is **consistent with DO serialisation / DO-path distress and does not prove a DO-internal phase** (§6.2.1: dispatch vs constructor vs handler remains behind Cloudflare telemetry under John's authorization — this dataset deliberately does not claim it).

Dataset-wide, the same split holds: ready legs answering 200 (n=48) have wait median 490 ms / TLS median 118.5 ms; ready legs answering 503 (n=32) have wait median 1,435.5 ms / TLS median 125.5 ms — wait roughly triples while TLS is flat.

## verify-claim-checkable claims

- Dataset file at the path above: 205,165 bytes, sha256 `ffbe429d0c612ec4d1987550c60798d73c2dc91b27a332d2b52c84643b673c0c`, 441 lines (1 header + 400 legs + 40 trailers); every trailer `legs: 10`.
- 40 supervisor invocations, all exit 0; `capture-logs/` holds 80 files, all 0 bytes → zero WRITE-REFUSED payloads, zero SUSPENDED lines.
- 32 leg records with `http_code 503`, all `leg "ready"`, all `do_status "timeout"` (app 17, entry 15); 40 leg records with `http_code 302`, all `entry/home`.
- `version` legs split 21/21 per door on `src_rev 2d72bb7f` (cycles 1–21) and 19/19 per door on `eaa97768` (cycles 22–40).
- Record-type census contains only `header`, `leg`, `cycle` — no `gap`, `ratelimit`, `forbidden` or `tool_error` records exist in the file.
- Checkpoint at `data/checkpoint.json`: `last_cycle_id 20261029T062219Z-0040`, `cycle_seq 40`, `last_write_status "ok"`, `suspended_until_ts_ms 0`.
