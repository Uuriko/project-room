# UT-4B — REPORT: incident-telemetry probe build

**Close state: SHIPPED-LOCAL.** Build of UT-4A's DESIGN.md §8 checklist, verified by the offline suite (11/11), a forced-refusal run, a latched-parent run, and a 3-cycle live smoke. Spend: ~0.5 lane-hours (UT-4B). No room posts. Production contact was unauthenticated GET only. No GitHub calls.

## Deliverables

| Path | What |
|---|---|
| `probe/incident-probe.mjs` | Supervisor + worker, one file, Node builtins only (`node:*` imports only; T5-grep tested). Supervisor: spawns no git/python, no network fetch, imports nothing from fleet-tools/; spawns the worker, reads its stdout to EOF, then writes. Worker: one fresh `curl` per leg with the explicit `-w` field template from DESIGN §2, small bodies captured for `version`/`ready` only, writes no file ever. |
| `probe/run-cycle.mjs` | Cycle runner for UT-4C: spawns one fresh supervisor per invocation, always a full cycle (both doors, both tiers via `--force-slow`; `--fast-only` opts out). Exit code = supervisor's. |
| `probe/incident-probe.test.mjs` | Offline suite (§8.3 a–e + latch + refusal + T5). Run: `node --test incident-probe.test.mjs`. |
| `probe/README.md` | UT-4C operator notes: usage, exit codes, in-band records. |
| `smoke-data/telemetry-2026-10-29.jsonl` + `checkpoint.json` | Live-smoke dataset (3 real cycles), kept as evidence. |

Dataset writer (DESIGN §5.2/§5.3, inlined, not imported): append-only daily JSONL; per-cycle append verified by size equality plus sha256 readback of exactly the appended byte range; checkpoint written only after the dataset, via the inlined atomic swap (tmp + fsync + sha256 readback + rename + best-effort dir fsync). On any append throw or verify mismatch: payload verbatim on stdout, one `WRITE-REFUSED ... code=<...> lines=<n> bytes=<n>` line on stderr, exit 2, no in-subtree retry.

## Acceptance evidence (DESIGN §8 + charter items)

**1. Real cycle, separated phases, ms-epoch timestamps, status, bytes.** Live smoke: 3 full cycles via `run-cycle.mjs`, all exit 0. Dataset: 34 records = 1 header + 30 leg records (10 legs × 3 cycles, every door/leg present 3×) + 3 cycle trailers. Statuses observed: 200, 302 (entry home), 503 (ready). Sample live `app/ready` record: `dns_ms:1, tcp_ms:0, tls_ms:102, wait_ms:561, xfer_ms:0, total_ms:663, body_bytes:195, ts_ms:1793253388907, http_code:200, ready_status:"ready", do_status:"ok", do_ms:388` — plus the cumulative `cum_ms` block on every record so derivations re-check. Phase ranges across the 30 legs: dns 0–4, tcp 0–1, tls 96–266, wait 208–3360, xfer 0–234, total 336–3525 — phases move independently, they do not collapse into one number. `version` legs pinned the build in-band: `src_rev 2d72bb7f`, `build_id 2026-10-29T05:36:10.253Z`, matching wave STATE.md's production read. Bonus: the smoke caught 3 live 503 `ready` flaps (both doors) with `ready_status:"degraded", do_status:"timeout"`, wait 1221–1822 ms against tls 99–145 ms — DESIGN §6.1 row 2's pattern, from the instrument's own first run.

**2. Incomplete phases stored null, never 0.** Unit tests on recorded-shape curl outputs: TLS failure → `tls_ms/wait_ms/xfer_ms` all null with dns/tcp populated; timeout before first byte → wait/xfer null, `total_ms` kept. Also observed live-in-scratch during an early (deadlocked-stub) run: all 10 legs recorded as data with `curl_exit:28`, error string, and null phases rather than holes. Suite test asserts the null rule at both derivation and record level; the live smoke had 0 phase-type violations across 30 legs.

**3. Deliberately-latched-subtree test.** Wrapper parent executed `git --version` first, then spawned the supervisor as its child, dataset pre-seeded with a 42-byte sentinel header (sha256 `a92497fb…`). Outcome: **landed via the fresh subtree** — supervisor exit 0, dataset 42 → 2192 bytes, sentinel prefix byte-identical, exactly 4 fast leg records + exactly 1 cycle trailer appended, checkpoint written, no `.tmp-` litter. (This branch is the one the task allows: fresh-subtree landing. The refusal branch is proven deterministically in item 4, down the same §5.4 code path.) The suite's latch test asserts either branch and forbids the third outcome (silent truncation/absence).

**4. WRITE-REFUSED stdout fallback (deterministic forced refusal).** Dataset daily path made a directory → append throws EISDIR. Result: exit 2; stderr exactly `WRITE-REFUSED incident-probe cycle=20261029T055551Z-0001 code=EISDIR lines=6 bytes=2473`; stdout carried all 6 payload lines (header + 4 legs + trailer) as parseable JSONL; the target was untouched. One real bug found and fixed by this test: the gap reader initially crashed (uncaught EISDIR) before the fallback could engage — `lastTrailerTs` now treats an unreadable tail as "no trailer" and lets the append path decide refusal.

**5. 429/403 simulation.** Local HTTP stub (stood up in scratch / in-suite): stub returns 429 on the first `ready` leg → cycle aborts immediately (dataset holds app version + app ready + `ratelimit` marker + trailer, no entry legs), checkpoint `suspended_until_ts_ms` set ~15 min out, an immediate re-run exits 3 with `SUSPENDED` on stderr and writes nothing (dataset size unchanged). The identical scenario with 403 produces the `forbidden` marker and the same abort + suspension. Forced-status runs were against the local stub only; production was never sent a synthetic status.

**6. Gap markers.** Seeded dataset with a trailer 10 min stale → next cycle's payload begins with `{"type":"gap","from_ts_ms":<stale trailer ts>,"to_ts_ms":<cycle start>,"missed_cycles_est":19}`. Covered in-suite.

**7. §8.3 test inventory.** (a) derivation unit tests — healthy / 503-with-body / TLS-failure nulls / timeout ✔ (b) schema test on a fixture cycle against a stub, all 10 legs ✔ (c) latched-subtree ✔ (d) gap ✔ (e) ratelimit + forbidden against a local stub ✔ (f) live smoke, 3 real cycles, all 10 legs schema-valid ✔. Suite total: **11/11 pass in ~2.4 s**, fully offline except the separate smoke.

## Notes for UT-4C / UT-4D

- Run shape: one `run-cycle.mjs` invocation per cycle from the driver; do not wrap it in a long-lived loop process (§5.1 rule 1 — fresh top-level process per write cycle is the safety property, and the runner preserves it).
- Exit 2 output is recoverable data: whoever runs the driver should capture supervisor stdout so a refused cycle's payload can be filed into the dataset verbatim (records are timestamp-true; order does not matter).
- Residual risk is DESIGN §5.5's, unchanged: if the latch scope proves broader than a subtree, cycles degrade to labelled gaps + stdout payloads, never silent loss. The latched-parent run above landed, which is one positive data point for the subtree scope, not a proof of it.

## verify-claim-checkable claims

- Suite: `node --test incident-probe.test.mjs` in `probe/` → 11 pass, 0 fail (this run, ~2.4 s).
- Live smoke dataset at `smoke-data/telemetry-2026-10-29.jsonl`: 34 lines; leg count by door/leg = 3 each for all 10; 3 leg records with `http_code:503`, all `leg:"ready"` with `do_status:"timeout"`; `version` records carry `src_rev:"2d72bb7f"`.
- Latched run numbers: sentinel sha256 `a92497fb572cd6934fe91193662e80445eee7383359d2d96af37d364b7c46821` at 42 bytes before; 2192 bytes after, exit 0.
- Refusal run: stderr line quoted in item 4 verbatim; probe exit code 2.
- Grep check: `probe/incident-probe.mjs` contains no `fleet-tools` import and no import outside `node:*` (asserted by the T5 test; the only `fleet-tools/` occurrences in the file are explanatory comments).
