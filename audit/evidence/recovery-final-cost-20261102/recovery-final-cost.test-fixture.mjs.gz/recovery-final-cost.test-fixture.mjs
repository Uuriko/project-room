// Disposable synthetic qualification only; never a production entrypoint.
import entry,{DurableCoverageRoom as Base} from './durable-coverage-native.test-fixture.mjs';
export class DurableCoverageRoom extends Base {
  constructor(ctx,env){
    super(ctx,env);this.samples=[];this.active=null;this.phase='finalization';
    const readTransaction=this.store.readTransaction.bind(this.store);
    this.store.readTransaction=operation=>{
      const previous=this.phase;
      if(new Error().stack.includes('auditRecovery'))this.phase='auditRecovery';
      try{return readTransaction(operation);}finally{this.phase=previous;}
    };
    const exec=ctx.storage.sql.exec.bind(ctx.storage.sql);
    ctx.storage.sql.exec=(sql,...params)=>{
      const cursor=exec(sql,...params),sample=this.active;
      if(!sample)return cursor;
      const record={phase:this.phase,sql:sql.replace(/\s+/g,' ').trim(),stack:new Error().stack.split('\n').slice(2,18),cursor,materializedBytes:0,materializedRows:0};
      sample.records.push(record);
      const charge=row=>{record.materializedRows++;record.materializedBytes+=new TextEncoder().encode(JSON.stringify(row)).byteLength;};
      return new Proxy(cursor,{get(target,key){
        if(key==='toArray')return()=>{const rows=target.toArray();for(const row of rows)charge(row);return rows;};
        if(key===Symbol.iterator)return function*(){for(const row of target) {charge(row);yield row;}};
        const value=Reflect.get(target,key,target);return typeof value==='function'?value.bind(target):value;
      }});
    };
  }
  async fetch(request){
    if(new URL(request.url).pathname==='/__audit-cost')return Response.json(this.samples);
    if(request.headers.get('x-measure-final')!=='1')return super.fetch(request);
    const sample={records:[]},started=performance.now();this.active=sample;
    try{return await super.fetch(request);}
    finally{
      this.active=null;
      const groups=new Map();let unknown=0;
      for(const record of sample.records){let rowsRead,rowsWritten;
        try{rowsRead=record.cursor.rowsRead;rowsWritten=record.cursor.rowsWritten;}catch{}
        if(!Number.isSafeInteger(rowsRead)||!Number.isSafeInteger(rowsWritten))unknown++;
        const key=JSON.stringify([record.phase,record.sql,record.stack]);const group=groups.get(key)??{phase:record.phase,sql:record.sql,stack:record.stack,statements:0,rowsRead:0,rowsWritten:0,materializedBytes:0,materializedRows:0};
        group.statements++;group.rowsRead+=rowsRead??0;group.rowsWritten+=rowsWritten??0;group.materializedBytes+=record.materializedBytes;group.materializedRows+=record.materializedRows;groups.set(key,group);
      }
      this.samples.push({observedWallMs:performance.now()-started,unknown,groups:[...groups.values()]});
    }
  }
}
export default entry;
